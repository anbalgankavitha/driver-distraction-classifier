@echo off
setlocal

rem Start the RAG backend and frontend in separate command windows.
rem PostgreSQL and Ollama must already be running.

set "PROJECT_DIR=%~dp0"

rem Test database defaults. Set DB_PASSWORD in Windows environment variables
rem before launching this file if your PostgreSQL password is not "postgres".
if not defined DB_URL set "DB_URL=jdbc:postgresql://localhost:5432/rag_test"
if not defined DB_USER set "DB_USER=postgres"
if not defined DB_PASSWORD set "DB_PASSWORD=postgres"

rem Models installed on the machine (nomic-embed-text is 768 dimensions).
if not defined OLLAMA_URL set "OLLAMA_URL=http://localhost:11434"
if not defined OLLAMA_CHAT_MODEL set "OLLAMA_CHAT_MODEL=llama3.1:8b"
if not defined OLLAMA_EMBEDDING_MODEL set "OLLAMA_EMBEDDING_MODEL=nomic-embed-text"

where mvn >nul 2>nul
if errorlevel 1 (
    echo Maven was not found. Install Maven or add mvn to PATH.
    pause
    exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
    echo npm was not found. Install Node.js and add npm to PATH.
    pause
    exit /b 1
)

if not exist "%PROJECT_DIR%frontend\node_modules\vite\bin\vite.js" (
    echo Frontend dependencies are missing. Run "npm install" once in the frontend folder.
    pause
    exit /b 1
)

start "RAG Backend" cmd /k "cd /d ""%PROJECT_DIR%backend"" && mvn spring-boot:run"
start "RAG Frontend" cmd /k "cd /d ""%PROJECT_DIR%frontend"" && npm run dev"

echo Backend and frontend are starting in separate windows.
echo Open http://localhost:5173 after Vite reports that it is ready.
endlocal
