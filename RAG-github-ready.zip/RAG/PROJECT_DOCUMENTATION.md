# DocIntel — Local RAG Project Guide

DocIntel is a local document question-answering application. It extracts text from uploaded files, indexes the text as vector embeddings, and answers questions using relevant document passages. The stack is React + TypeScript, Spring Boot (Java 11), PostgreSQL with pgvector, and Ollama.

## Screenshots

The following screenshots were captured from the running local application and are included in the PDF and in `docs/images/`:

| File | Screen |
| --- | --- |
| `dashboard.png` | Dashboard, service health, model status, and index synchronization |
| `documents.png` | Uploaded documents, status, chunk counts, and document actions |
| `chat.png` | A document question, answer, and cited sources |
| `settings.png` | Ollama models, chunking/retrieval, and storage settings |

![DocIntel dashboard](docs/images/dashboard.png)

![DocIntel documents](docs/images/documents.png)

![DocIntel chat with cited sources](docs/images/chat.png)

![DocIntel settings](docs/images/settings.png)

## Features

- Upload TXT, PDF, DOC, and DOCX documents; upload multiple files at once.
- Extract text and split it into chunks while retaining available page and section information.
- Generate embeddings with an Ollama embedding model and store them in pgvector.
- Ask questions against the indexed documents and view the sources used in an answer.
- Manage conversations, reindex one or all documents, and inspect a document's chunks.
- Review database, pgvector, and Ollama health on the dashboard; validate and repair index synchronization.
- Configure Ollama, chunking, retrieval, file storage, and upload limits from Settings.

## Architecture and indexing flow

1. The React frontend sends requests to the Spring Boot API on port `8080`.
2. The backend stores the uploaded file under the configured storage directory and records document metadata in PostgreSQL.
3. Apache Tika/PDFBox-based extraction produces text sections. `TextChunker` packs paragraphs up to the configured chunk size and splits oversized paragraphs into overlapping windows. Sections are kept separate to preserve page attribution.
4. Chunk size and overlap are currently measured as whitespace-separated words, which is an approximation of model tokens.
5. Ollama creates an embedding for each chunk. Chunk text, metadata, and vectors are stored in `document_chunks`.
6. During chat, the backend embeds the question and searches active vectors using pgvector cosine distance. It applies the similarity threshold, removes highly redundant matches, and returns up to Top-K chunks to the chat model.
7. Indexing writes a new version first and switches the document's active version after the new chunks have been stored and validated.

The schema creates an HNSW index using `vector_cosine_ops` for cosine nearest-neighbor search.

## Requirements

- Java 11
- Maven
- Node.js and npm
- PostgreSQL with the pgvector extension available
- Ollama, with a chat model and an embedding model installed

The configured embedding column has 768 dimensions by default. The selected embedding model must return the same number of dimensions. The default embedding model is `nomic-embed-text`.

## Local setup

### 1. Configure PostgreSQL

Create a PostgreSQL database and user, then update `backend/src/main/resources/application.yml` to match your local connection. The checked-in development configuration currently uses database `rag1`, port `5433`, user `postgres`, and password `root`; replace these values for your environment and do not use development credentials in a shared or production environment.

Flyway applies the schema migrations automatically when the backend starts. The initial schema enables pgvector and creates the documents, chunks, and vector index tables. The next migration adds chat history and persisted settings.

### 2. Start Ollama and install models

Start Ollama and ensure the configured chat and embedding models are available. The defaults in `application.yml` are `llama3.1:8b` for chat and `nomic-embed-text` for embeddings. The Settings page can list and pull models from the configured Ollama server.

### 3. Start the backend

From the repository root:

```powershell
cd backend
mvn spring-boot:run
```

The API listens on `http://localhost:8080`.

### 4. Start the frontend

In a separate terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open the Vite URL, normally `http://localhost:5173`. A Windows helper, `start-apps.bat`, is also present; PostgreSQL and Ollama must be running first.

## Using the application

### Dashboard

The dashboard summarizes document and chunk counts, processing state, PostgreSQL/pgvector/Ollama health, and configured models. Its synchronization controls can validate the stored index and repair supported inconsistencies.

### Documents

Upload by choosing files or dragging them onto the upload area. A repeated filename replaces the existing document; identical content is skipped. Indexing runs in the background. The table shows status and chunk count, and actions allow viewing chunks, reindexing, replacing, or deleting a document.

Use **Reindex all** after changing chunk size or overlap to rebuild the existing document indexes with the new values. Reindexing is asynchronous; check document statuses for completion or errors.

### Chat

Ask a question in Chat. Answers use retrieved document context and show source document names and page numbers when available. If no chunks meet the configured similarity threshold, the application reports that the answer is not available in the indexed documents.

### Settings

Settings are persisted in the `app_settings` table and take effect after saving:

- Ollama URL, chat model, and embedding model.
- Chunk size and overlap for indexing. These are whitespace-word estimates, not the selected model's exact tokenizer counts. Reindex existing documents after changing them.
- Top-K and similarity threshold for subsequent retrievals.
- File storage directory for new uploads and maximum upload size.

Changing the embedding model makes existing vectors incompatible with the new model's search space. Reindex documents after changing it; the embedding dimensions must also match the database vector column.

## Useful API routes

| Method | Route | Purpose |
| --- | --- | --- |
| `GET` | `/api/system/health` | Component health and dashboard statistics |
| `GET` | `/api/documents` | List documents |
| `POST` | `/api/documents/upload/multiple` | Upload multiple files |
| `POST` | `/api/documents/{id}/reindex` | Queue one document for reindexing |
| `POST` | `/api/documents/reindex-all` | Queue all documents for reindexing |
| `GET` | `/api/documents/{id}/chunks` | Read active chunks for a document |
| `GET`, `PUT` | `/api/settings` | Read or save application settings |
| `POST` | `/api/chat/ask` | Ask a question |
| `POST` | `/api/system/sync/validate` | Validate index consistency |
| `POST` | `/api/system/sync/repair` | Repair supported consistency issues |

## Main source directories

- `frontend/src/pages/` — Dashboard, Documents, Chat, and Settings screens.
- `backend/src/main/java/com/example/rag/controller/` — HTTP API controllers.
- `backend/src/main/java/com/example/rag/service/` — ingestion, chunking, retrieval, chat, and settings logic.
- `backend/src/main/java/com/example/rag/repository/` — PostgreSQL and pgvector access.
- `backend/src/main/resources/db/migration/` — Flyway schema migrations.
