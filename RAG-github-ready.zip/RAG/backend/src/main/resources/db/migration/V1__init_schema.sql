CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE documents (
    id                BIGSERIAL PRIMARY KEY,
    original_filename VARCHAR(512)  NOT NULL,
    stored_filename   VARCHAR(255)  NOT NULL UNIQUE,
    file_type         VARCHAR(10)   NOT NULL,
    file_path         VARCHAR(1024) NOT NULL,
    file_size         BIGINT        NOT NULL,
    file_hash         VARCHAR(64)   NOT NULL,
    total_chunks      INTEGER       NOT NULL DEFAULT 0,
    processing_status VARCHAR(20)   NOT NULL,
    created_at        TIMESTAMP     NOT NULL DEFAULT now(),
    updated_at        TIMESTAMP     NOT NULL DEFAULT now(),
    last_indexed_at   TIMESTAMP,
    processing_error  TEXT,
    -- version-based indexing: only chunks whose index_version equals active_version are searchable
    active_version    INTEGER       NOT NULL DEFAULT 0,
    embedding_model   VARCHAR(255)
);

CREATE INDEX idx_documents_file_hash ON documents (file_hash);
CREATE INDEX idx_documents_status ON documents (processing_status);
CREATE INDEX idx_documents_original_filename ON documents (lower(original_filename));

CREATE TABLE document_chunks (
    id            BIGSERIAL PRIMARY KEY,
    document_id   BIGINT    NOT NULL REFERENCES documents (id) ON DELETE CASCADE,
    chunk_index   INTEGER   NOT NULL,
    chunk_text    TEXT      NOT NULL,
    page_number   INTEGER,
    section_title VARCHAR(512),
    embedding     vector(${embeddingDimensions}),
    created_at    TIMESTAMP NOT NULL DEFAULT now(),
    index_version INTEGER   NOT NULL DEFAULT 1,
    CONSTRAINT uq_chunk_version_index UNIQUE (document_id, index_version, chunk_index)
);

CREATE INDEX idx_chunks_document_id ON document_chunks (document_id);
CREATE INDEX idx_chunks_document_version ON document_chunks (document_id, index_version);
-- Approximate nearest-neighbour index (cosine distance). Requires pgvector >= 0.5.0.
CREATE INDEX idx_chunks_embedding_hnsw ON document_chunks USING hnsw (embedding vector_cosine_ops);

CREATE TABLE ingestion_jobs (
    id            BIGSERIAL PRIMARY KEY,
    document_id   BIGINT      NOT NULL REFERENCES documents (id) ON DELETE CASCADE,
    job_status    VARCHAR(20) NOT NULL,
    started_at    TIMESTAMP   NOT NULL DEFAULT now(),
    completed_at  TIMESTAMP,
    error_message TEXT
);

CREATE INDEX idx_ingestion_jobs_document_id ON ingestion_jobs (document_id);
