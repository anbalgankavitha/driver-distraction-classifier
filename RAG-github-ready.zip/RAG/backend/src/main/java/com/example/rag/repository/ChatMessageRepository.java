package com.example.rag.repository;

import com.example.rag.entity.ChatMessage;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    List<ChatMessage> findByConversationIdOrderByIdAsc(String conversationId);

    @Query("select m from ChatMessage m where m.conversationId = :cid order by m.id desc")
    List<ChatMessage> findLatest(@Param("cid") String conversationId, Pageable pageable);

    long countByConversationId(String conversationId);
}
