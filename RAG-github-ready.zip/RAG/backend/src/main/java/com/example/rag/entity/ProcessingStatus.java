package com.example.rag.entity;

public enum ProcessingStatus {
    UPLOADED,
    PROCESSING,
    COMPLETED,
    FAILED,
    REINDEXING
}
