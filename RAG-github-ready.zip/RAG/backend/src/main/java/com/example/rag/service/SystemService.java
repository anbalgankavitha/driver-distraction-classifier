package com.example.rag.service;

import com.example.rag.dto.ComponentStatusDto;
import com.example.rag.dto.DashboardStatsDto;
import com.example.rag.dto.HealthDto;
import com.example.rag.dto.OllamaStatusDto;
import com.example.rag.entity.ProcessingStatus;
import com.example.rag.repository.ChunkRepository;
import com.example.rag.repository.DocumentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class SystemService {

    private static final Logger log = LoggerFactory.getLogger(SystemService.class);

    private final ChunkRepository chunks;
    private final DocumentRepository documents;
    private final OllamaClient ollama;

    public SystemService(ChunkRepository chunks, DocumentRepository documents, OllamaClient ollama) {
        this.chunks = chunks;
        this.documents = documents;
        this.ollama = ollama;
    }

    public HealthDto health() {
        HealthDto health = new HealthDto();
        health.database = checkDatabase();
        health.pgvector = health.database.up ? checkPgvector()
                : new ComponentStatusDto(false, "Unknown (database unavailable)");
        health.ollama = ollama.status();
        health.stats = health.database.up ? stats() : new DashboardStatsDto();
        boolean allUp = health.database.up && health.pgvector.up && health.ollama.reachable;
        health.status = allUp ? "UP" : "DEGRADED";
        return health;
    }

    private ComponentStatusDto checkDatabase() {
        try {
            chunks.ping();
            return new ComponentStatusDto(true, "Connected");
        } catch (RuntimeException e) {
            log.warn("Database health check failed: {}", e.getClass().getSimpleName());
            return new ComponentStatusDto(false, "PostgreSQL is not reachable");
        }
    }

    private ComponentStatusDto checkPgvector() {
        try {
            String version = chunks.pgvectorVersion();
            return version == null
                    ? new ComponentStatusDto(false, "pgvector extension is not installed")
                    : new ComponentStatusDto(true, "pgvector " + version);
        } catch (RuntimeException e) {
            return new ComponentStatusDto(false, "pgvector status could not be determined");
        }
    }

    private DashboardStatsDto stats() {
        DashboardStatsDto stats = new DashboardStatsDto();
        stats.totalDocuments = documents.count();
        stats.completedDocuments = documents.countByProcessingStatusIn(Collections.singleton(ProcessingStatus.COMPLETED));
        stats.failedDocuments = documents.countByProcessingStatusIn(Collections.singleton(ProcessingStatus.FAILED));
        stats.processingDocuments = documents.countByProcessingStatusIn(java.util.Arrays.asList(
                ProcessingStatus.UPLOADED, ProcessingStatus.PROCESSING, ProcessingStatus.REINDEXING));
        stats.totalChunks = chunks.countActive();
        return stats;
    }

    public OllamaStatusDto ollamaStatus() {
        return ollama.status();
    }
}
