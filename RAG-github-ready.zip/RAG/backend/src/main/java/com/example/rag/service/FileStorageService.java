package com.example.rag.service;

import com.example.rag.exception.ApiException;
import com.example.rag.exception.BadRequestException;
import com.example.rag.model.StoredFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

/** Validates and stores uploaded files under generated internal names, and cleans them up. */
@Service
public class FileStorageService {

    private static final Logger log = LoggerFactory.getLogger(FileStorageService.class);
    private static final Set<String> ALLOWED_EXTENSIONS = new HashSet<>(Arrays.asList("txt", "pdf", "doc", "docx"));

    private final SettingsService settings;

    public FileStorageService(SettingsService settings) {
        this.settings = settings;
    }

    public StoredFile store(MultipartFile file) {
        String original = sanitizeFilename(file.getOriginalFilename());
        String extension = extensionOf(original);
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new BadRequestException("Unsupported file type. Allowed types: TXT, PDF, DOC, DOCX.");
        }
        if (file.isEmpty()) {
            throw new BadRequestException("The uploaded file is empty.");
        }
        long maxBytes = settings.snapshot().maxUploadSizeMb * 1024L * 1024L;
        if (file.getSize() > maxBytes) {
            throw new ApiException(HttpStatus.PAYLOAD_TOO_LARGE,
                    "The file exceeds the maximum upload size of " + settings.snapshot().maxUploadSizeMb + " MB.");
        }

        Path directory = storageDirectory();
        String storedName = UUID.randomUUID() + "." + extension;
        Path target = directory.resolve(storedName).normalize();
        if (!directory.equals(target.getParent())) {
            throw new BadRequestException("Invalid file name.");
        }

        MessageDigest digest = newDigest();
        try {
            Files.createDirectories(directory);
            try (InputStream in = new DigestInputStream(file.getInputStream(), digest)) {
                Files.copy(in, target);
            }
            verifySignature(target, extension);
            return new StoredFile(original, storedName, target, Files.size(target), toHex(digest.digest()), extension);
        } catch (IOException e) {
            deleteQuietly(target);
            log.error("Failed to store uploaded file: {}", e.getClass().getSimpleName());
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "The file could not be stored.", e);
        } catch (RuntimeException e) {
            deleteQuietly(target);
            throw e;
        }
    }

    public boolean exists(String path) {
        return path != null && Files.isRegularFile(Paths.get(path));
    }

    public void deleteQuietly(Path path) {
        if (path == null) {
            return;
        }
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            log.warn("Could not delete stored file {}: {}", path.getFileName(), e.getClass().getSimpleName());
        }
    }

    public void deleteQuietly(String path) {
        if (path != null) {
            deleteQuietly(Paths.get(path));
        }
    }

    public List<Path> listStoredFiles() {
        Path directory = storageDirectory();
        if (!Files.isDirectory(directory)) {
            return new ArrayList<>();
        }
        try (Stream<Path> stream = Files.list(directory)) {
            List<Path> files = new ArrayList<>();
            stream.filter(Files::isRegularFile).forEach(files::add);
            return files;
        } catch (IOException e) {
            log.warn("Could not list storage directory: {}", e.getClass().getSimpleName());
            return new ArrayList<>();
        }
    }

    public static Path normalize(String path) {
        return Paths.get(path).toAbsolutePath().normalize();
    }

    public static String sha256(Path path) throws IOException {
        MessageDigest digest = newDigest();
        try (InputStream in = new DigestInputStream(Files.newInputStream(path), digest)) {
            byte[] buffer = new byte[8192];
            while (in.read(buffer) != -1) {
                // reading drives the digest
            }
        }
        return toHex(digest.digest());
    }

    private Path storageDirectory() {
        return Paths.get(settings.snapshot().storageLocation).toAbsolutePath().normalize();
    }

    private static String sanitizeFilename(String raw) {
        if (raw == null) {
            throw new BadRequestException("The uploaded file has no name.");
        }
        String name = raw.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1).replaceAll("\\p{Cntrl}", "").trim();
        if (name.isEmpty() || name.equals(".") || name.equals("..")) {
            throw new BadRequestException("The uploaded file has an invalid name.");
        }
        if (name.length() > 255) {
            throw new BadRequestException("The file name is too long.");
        }
        return name;
    }

    private static String extensionOf(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot < 0 ? "" : filename.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    /** Lightweight content sniffing so a renamed binary cannot masquerade as a supported document. */
    private static void verifySignature(Path file, String extension) throws IOException {
        byte[] head = new byte[4096];
        int read;
        try (InputStream in = Files.newInputStream(file)) {
            read = in.read(head);
        }
        if (read <= 0) {
            throw new BadRequestException("The uploaded file is empty.");
        }
        boolean valid;
        switch (extension) {
            case "pdf":
                valid = read >= 4 && head[0] == '%' && head[1] == 'P' && head[2] == 'D' && head[3] == 'F';
                break;
            case "docx":
                valid = read >= 4 && head[0] == 'P' && head[1] == 'K';
                break;
            case "doc":
                valid = read >= 4 && (head[0] & 0xFF) == 0xD0 && (head[1] & 0xFF) == 0xCF
                        && (head[2] & 0xFF) == 0x11 && (head[3] & 0xFF) == 0xE0;
                break;
            default:
                valid = true;
                for (int i = 0; i < read; i++) {
                    if (head[i] == 0) {
                        valid = false;
                        break;
                    }
                }
        }
        if (!valid) {
            throw new BadRequestException("The file content does not match its extension.");
        }
    }

    private static MessageDigest newDigest() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
