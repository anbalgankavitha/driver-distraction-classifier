package com.example.rag.dto;

import java.util.List;

public class ChatResponseDto {

    public String conversationId;
    public ChatMessageDto message;
    public List<SourceDto> sources;
}
