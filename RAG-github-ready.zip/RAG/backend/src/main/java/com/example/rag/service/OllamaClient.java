package com.example.rag.service;

import com.example.rag.dto.OllamaModelDto;
import com.example.rag.dto.OllamaStatusDto;
import com.example.rag.dto.SettingsDto;
import com.example.rag.exception.OllamaUnavailableException;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Thin client for the local Ollama HTTP API. The URL and model names are read from runtime settings per call. */
@Component
public class OllamaClient {

    private static final Logger log = LoggerFactory.getLogger(OllamaClient.class);
    private static final int EMBED_BATCH_SIZE = 16;

    private final SettingsService settings;
    private final RestTemplate http;
    private final RestTemplate probe;
    private final RestTemplate modelPull;

    @Value("${app.ollama.chat-context-window:8192}")
    private int contextWindow;

    @Value("${app.ollama.temperature:0.1}")
    private double temperature;

    public OllamaClient(SettingsService settings, RestTemplateBuilder builder) {
        this.settings = settings;
        this.http = builder.setConnectTimeout(Duration.ofSeconds(5)).setReadTimeout(Duration.ofMinutes(5)).build();
        this.probe = builder.setConnectTimeout(Duration.ofSeconds(3)).setReadTimeout(Duration.ofSeconds(5)).build();
        this.modelPull = builder.setConnectTimeout(Duration.ofSeconds(5)).setReadTimeout(Duration.ofHours(2)).build();
    }

    public float[] embed(String text, String model) {
        return embedAll(Collections.singletonList(text), model).get(0);
    }

    public List<float[]> embedAll(List<String> texts, String model) {
        String base = settings.snapshot().ollamaUrl;
        List<float[]> result = new ArrayList<>(texts.size());
        for (int from = 0; from < texts.size(); from += EMBED_BATCH_SIZE) {
            List<String> batch = texts.subList(from, Math.min(texts.size(), from + EMBED_BATCH_SIZE));
            result.addAll(embedBatch(base, model, batch));
        }
        return result;
    }

    public String chat(List<Map<String, String>> messages) {
        SettingsDto s = settings.snapshot();
        Map<String, Object> options = new HashMap<>();
        options.put("temperature", temperature);
        options.put("num_ctx", contextWindow);
        Map<String, Object> body = new HashMap<>();
        body.put("model", s.chatModel);
        body.put("messages", messages);
        body.put("stream", false);
        body.put("options", options);
        try {
            JsonNode response = http.postForObject(s.ollamaUrl + "/api/chat", body, JsonNode.class);
            String content = response == null ? "" : response.path("message").path("content").asText("");
            return content.trim();
        } catch (RestClientException e) {
            throw unavailable("chat", s.chatModel, e);
        }
    }

    public OllamaStatusDto status() {
        SettingsDto s = settings.snapshot();
        OllamaStatusDto status = new OllamaStatusDto();
        status.url = s.ollamaUrl;
        status.chatModel = s.chatModel;
        status.embeddingModel = s.embeddingModel;
        try {
            status.models = fetchModels(s.ollamaUrl);
            status.reachable = true;
            status.chatModelAvailable = hasModel(status.models, s.chatModel);
            status.embeddingModelAvailable = hasModel(status.models, s.embeddingModel);
            status.message = "Connected";
            if (!status.chatModelAvailable || !status.embeddingModelAvailable) {
                status.message = "Connected, but a configured model is not pulled in Ollama.";
            }
        } catch (RestClientException e) {
            status.reachable = false;
            status.message = "Ollama is not reachable at " + s.ollamaUrl;
        }
        return status;
    }

    /** Throws OllamaUnavailableException when Ollama cannot be reached. */
    public List<OllamaModelDto> models() {
        String base = settings.snapshot().ollamaUrl;
        try {
            return fetchModels(base);
        } catch (RestClientException e) {
            throw new OllamaUnavailableException("Ollama is not reachable at " + base, e);
        }
    }

    /** Downloads a model from the configured Ollama server and waits for the pull to finish. */
    public void pullModel(String model) {
        String base = settings.snapshot().ollamaUrl;
        Map<String, Object> body = new HashMap<>();
        body.put("model", model);
        body.put("stream", false);
        try {
            JsonNode response = modelPull.postForObject(base + "/api/pull", body, JsonNode.class);
            if (response == null || !"success".equalsIgnoreCase(response.path("status").asText())) {
                throw new OllamaUnavailableException("Ollama did not confirm that model '" + model + "' was pulled.");
            }
        } catch (RestClientException e) {
            throw unavailable("model pull", model, e);
        }
    }

    private List<OllamaModelDto> fetchModels(String base) {
        JsonNode response = probe.getForObject(base + "/api/tags", JsonNode.class);
        List<OllamaModelDto> models = new ArrayList<>();
        if (response != null && response.has("models")) {
            for (JsonNode m : response.get("models")) {
                models.add(new OllamaModelDto(m.path("name").asText(), m.path("size").asLong(0)));
            }
        }
        return models;
    }

    private static boolean hasModel(List<OllamaModelDto> models, String wanted) {
        for (OllamaModelDto m : models) {
            if (m.name.equals(wanted) || m.name.equals(wanted + ":latest")
                    || (wanted.endsWith(":latest") && m.name.equals(wanted.substring(0, wanted.length() - 7)))) {
                return true;
            }
        }
        return false;
    }

    private List<float[]> embedBatch(String base, String model, List<String> batch) {
        try {
            Map<String, Object> body = new HashMap<>();
            body.put("model", model);
            body.put("input", batch);
            JsonNode response = http.postForObject(base + "/api/embed", body, JsonNode.class);
            JsonNode embeddings = response == null ? null : response.get("embeddings");
            if (embeddings == null || embeddings.size() != batch.size()) {
                throw new OllamaUnavailableException("Ollama returned an unexpected embedding response.");
            }
            List<float[]> vectors = new ArrayList<>(batch.size());
            for (JsonNode node : embeddings) {
                vectors.add(toArray(node));
            }
            return vectors;
        } catch (HttpClientErrorException.NotFound notFound) {
            return embedBatchLegacy(base, model, batch);
        } catch (RestClientException e) {
            throw unavailable("embedding", model, e);
        }
    }

    /** Fallback for older Ollama versions that only expose /api/embeddings. */
    private List<float[]> embedBatchLegacy(String base, String model, List<String> batch) {
        List<float[]> vectors = new ArrayList<>(batch.size());
        try {
            for (String text : batch) {
                Map<String, Object> body = new HashMap<>();
                body.put("model", model);
                body.put("prompt", text);
                JsonNode response = http.postForObject(base + "/api/embeddings", body, JsonNode.class);
                JsonNode embedding = response == null ? null : response.get("embedding");
                if (embedding == null) {
                    throw new OllamaUnavailableException("Ollama returned an unexpected embedding response.");
                }
                vectors.add(toArray(embedding));
            }
            return vectors;
        } catch (RestClientException e) {
            throw unavailable("embedding", model, e);
        }
    }

    private static float[] toArray(JsonNode node) {
        float[] vector = new float[node.size()];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = (float) node.get(i).asDouble();
        }
        return vector;
    }

    private OllamaUnavailableException unavailable(String operation, String model, RestClientException e) {
        log.warn("Ollama {} request failed for model {}: {}", operation, model, e.getClass().getSimpleName());
        if (e instanceof ResourceAccessException) {
            return new OllamaUnavailableException(
                    "Ollama is not reachable. Make sure Ollama is running and the URL in Settings is correct.", e);
        }
        if (e instanceof HttpStatusCodeException) {
            int code = ((HttpStatusCodeException) e).getRawStatusCode();
            if (code == 404) {
                if ("model pull".equals(operation)) {
                    return new OllamaUnavailableException("Ollama could not find model '" + model
                            + "'. Check the model name and tag.", e);
                }
                return new OllamaUnavailableException("Ollama model '" + model
                        + "' was not found. Pull it first (ollama pull " + model + ").", e);
            }
            return new OllamaUnavailableException("Ollama returned HTTP " + code + " for the " + operation + " request.", e);
        }
        return new OllamaUnavailableException("Ollama " + operation + " request failed.", e);
    }
}
