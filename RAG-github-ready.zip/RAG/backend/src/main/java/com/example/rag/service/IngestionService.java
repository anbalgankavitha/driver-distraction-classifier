package com.example.rag.service;

import com.example.rag.entity.Document;
import com.example.rag.entity.IngestionJob;
import com.example.rag.entity.JobStatus;
import com.example.rag.entity.ProcessingStatus;
import com.example.rag.exception.ApiException;
import com.example.rag.exception.ConflictException;
import com.example.rag.exception.NotFoundException;
import com.example.rag.model.StoredFile;
import com.example.rag.repository.DocumentRepository;
import com.example.rag.repository.IngestionJobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collection;

/** Claims a document for processing (preventing concurrent indexing) and hands it to the background worker. */
@Service
public class IngestionService {

    private static final Logger log = LoggerFactory.getLogger(IngestionService.class);
    private static final Collection<ProcessingStatus> BUSY =
            Arrays.asList(ProcessingStatus.PROCESSING, ProcessingStatus.REINDEXING);

    private final DocumentRepository documents;
    private final IngestionJobRepository jobs;
    private final IngestionWorker worker;

    public IngestionService(DocumentRepository documents, IngestionJobRepository jobs, IngestionWorker worker) {
        this.documents = documents;
        this.jobs = jobs;
        this.worker = worker;
    }

    public static Collection<ProcessingStatus> busyStatuses() {
        return BUSY;
    }

    /**
     * Queues (re)indexing of a document.
     *
     * @param replacement optional new file to replace the current one after successful indexing
     * @throws ConflictException when the document is already being processed
     */
    public Document submit(Long documentId, StoredFile replacement) {
        Document doc = documents.findById(documentId)
                .orElseThrow(() -> new NotFoundException("Document " + documentId + " was not found."));
        ProcessingStatus target = doc.getActiveVersion() > 0 ? ProcessingStatus.REINDEXING : ProcessingStatus.PROCESSING;
        if (documents.claim(documentId, target, BUSY) == 0) {
            throw new ConflictException("The document is already being processed.");
        }
        IngestionJob job = jobs.save(new IngestionJob(documentId));
        try {
            worker.process(documentId, job.getId(), replacement);
        } catch (TaskRejectedException e) {
            log.error("Ingestion queue rejected document {}", documentId);
            doc = documents.findById(documentId).orElse(doc);
            doc.setProcessingStatus(ProcessingStatus.FAILED);
            doc.setProcessingError("The ingestion queue is full. Try again later.");
            documents.save(doc);
            job.setJobStatus(JobStatus.FAILED);
            job.setErrorMessage("Queue full");
            jobs.save(job);
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "The ingestion queue is full. Try again later.", e);
        }
        return documents.findById(documentId).orElse(doc);
    }
}
