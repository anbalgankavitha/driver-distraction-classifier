package com.example.rag.dto;

import java.util.ArrayList;
import java.util.List;

public class SyncRepairDto {

    public int issuesFound;
    public int repaired;
    public int failed;
    public List<String> actions = new ArrayList<>();
}
