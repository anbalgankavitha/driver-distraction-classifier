package com.example.rag.model;

public class TextChunk {

    private final int index;
    private final Integer pageNumber;
    private final String sectionTitle;
    private final String text;

    public TextChunk(int index, Integer pageNumber, String sectionTitle, String text) {
        this.index = index;
        this.pageNumber = pageNumber;
        this.sectionTitle = sectionTitle;
        this.text = text;
    }

    public int getIndex() { return index; }
    public Integer getPageNumber() { return pageNumber; }
    public String getSectionTitle() { return sectionTitle; }
    public String getText() { return text; }
}
