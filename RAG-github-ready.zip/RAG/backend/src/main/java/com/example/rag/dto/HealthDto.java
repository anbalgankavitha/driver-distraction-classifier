package com.example.rag.dto;

public class HealthDto {

    /** UP when every component is available, otherwise DEGRADED. */
    public String status;
    public ComponentStatusDto database;
    public ComponentStatusDto pgvector;
    public OllamaStatusDto ollama;
    public DashboardStatsDto stats;
}
