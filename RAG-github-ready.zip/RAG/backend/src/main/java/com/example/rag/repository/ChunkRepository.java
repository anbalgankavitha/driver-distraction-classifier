package com.example.rag.repository;

import com.example.rag.dto.ChunkDto;
import com.example.rag.dto.SourceDto;
import com.example.rag.model.TextChunk;
import com.example.rag.util.VectorUtils;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

/**
 * JDBC access to document_chunks. Plain SQL is used because the pgvector column is not a standard JPA type.
 * A chunk is searchable only when its index_version equals the owning document's active_version.
 */
@Repository
public class ChunkRepository {

    private static final String ACTIVE_JOIN =
            " JOIN documents d ON d.id = c.document_id AND c.index_version = d.active_version ";

    private final JdbcTemplate jdbc;

    public ChunkRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insertBatch(long documentId, int version, List<TextChunk> chunks, List<float[]> embeddings) {
        String sql = "INSERT INTO document_chunks "
                + "(document_id, chunk_index, chunk_text, page_number, section_title, embedding, index_version) "
                + "VALUES (?, ?, ?, ?, ?, ?::vector, ?)";
        jdbc.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                TextChunk chunk = chunks.get(i);
                ps.setLong(1, documentId);
                ps.setInt(2, chunk.getIndex());
                ps.setString(3, chunk.getText());
                if (chunk.getPageNumber() == null) {
                    ps.setNull(4, Types.INTEGER);
                } else {
                    ps.setInt(4, chunk.getPageNumber());
                }
                ps.setString(5, chunk.getSectionTitle());
                ps.setString(6, VectorUtils.toLiteral(embeddings.get(i)));
                ps.setInt(7, version);
            }

            @Override
            public int getBatchSize() {
                return chunks.size();
            }
        });
    }

    public long countVersion(long documentId, int version) {
        Long n = jdbc.queryForObject(
                "SELECT count(*) FROM document_chunks WHERE document_id = ? AND index_version = ?",
                Long.class, documentId, version);
        return n == null ? 0 : n;
    }

    public void deleteOtherVersions(long documentId, int keepVersion) {
        jdbc.update("DELETE FROM document_chunks WHERE document_id = ? AND index_version <> ?", documentId, keepVersion);
    }

    public long countActive() {
        Long n = jdbc.queryForObject("SELECT count(*) FROM document_chunks c" + ACTIVE_JOIN, Long.class);
        return n == null ? 0 : n;
    }

    public long countActiveForDocument(long documentId) {
        Long n = jdbc.queryForObject(
                "SELECT count(*) FROM document_chunks c" + ACTIVE_JOIN + "WHERE c.document_id = ?",
                Long.class, documentId);
        return n == null ? 0 : n;
    }

    public long countActiveWithoutEmbedding(long documentId) {
        Long n = jdbc.queryForObject(
                "SELECT count(*) FROM document_chunks c" + ACTIVE_JOIN
                        + "WHERE c.document_id = ? AND c.embedding IS NULL",
                Long.class, documentId);
        return n == null ? 0 : n;
    }

    public long countStaleForDocument(long documentId) {
        Long n = jdbc.queryForObject(
                "SELECT count(*) FROM document_chunks c" + ACTIVE_JOIN
                        .replace("c.index_version = d.active_version", "c.index_version <> d.active_version")
                        + "WHERE c.document_id = ?",
                Long.class, documentId);
        return n == null ? 0 : n;
    }

    public int deleteStaleForDocument(long documentId) {
        return jdbc.update("DELETE FROM document_chunks c USING documents d "
                + "WHERE d.id = c.document_id AND c.document_id = ? AND c.index_version <> d.active_version", documentId);
    }

    public List<ChunkDto> findActiveByDocument(long documentId) {
        return jdbc.query(
                "SELECT c.id, c.chunk_index, c.chunk_text, c.page_number, c.section_title "
                        + "FROM document_chunks c" + ACTIVE_JOIN
                        + "WHERE c.document_id = ? ORDER BY c.chunk_index",
                (rs, rowNum) -> {
                    ChunkDto dto = new ChunkDto();
                    dto.id = rs.getLong("id");
                    dto.chunkIndex = rs.getInt("chunk_index");
                    dto.text = rs.getString("chunk_text");
                    int page = rs.getInt("page_number");
                    dto.pageNumber = rs.wasNull() ? null : page;
                    dto.sectionTitle = rs.getString("section_title");
                    return dto;
                }, documentId);
    }

    /** Nearest-neighbour search over active chunks produced by the given embedding model (cosine similarity). */
    public List<SourceDto> search(float[] queryEmbedding, String embeddingModel, int limit) {
        String literal = VectorUtils.toLiteral(queryEmbedding);
        String sql = "SELECT c.id, c.document_id, d.original_filename, c.chunk_index, c.chunk_text, "
                + "c.page_number, c.section_title, 1 - (c.embedding <=> ?::vector) AS similarity "
                + "FROM document_chunks c" + ACTIVE_JOIN
                + "WHERE c.embedding IS NOT NULL AND d.embedding_model = ? "
                + "ORDER BY c.embedding <=> ?::vector LIMIT ?";
        return jdbc.query(sql, (rs, rowNum) -> {
            SourceDto s = new SourceDto();
            s.chunkId = rs.getLong("id");
            s.documentId = rs.getLong("document_id");
            s.documentName = rs.getString("original_filename");
            s.chunkIndex = rs.getInt("chunk_index");
            s.text = rs.getString("chunk_text");
            int page = rs.getInt("page_number");
            s.pageNumber = rs.wasNull() ? null : page;
            s.sectionTitle = rs.getString("section_title");
            s.similarity = rs.getDouble("similarity");
            return s;
        }, literal, embeddingModel, literal, limit);
    }

    public String pgvectorVersion() {
        List<String> versions = jdbc.queryForList("SELECT extversion FROM pg_extension WHERE extname = 'vector'", String.class);
        return versions.isEmpty() ? null : versions.get(0);
    }

    public void ping() {
        jdbc.queryForObject("SELECT 1", Integer.class);
    }
}
