package com.example.rag.repository;

import com.example.rag.entity.Document;
import com.example.rag.entity.ProcessingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface DocumentRepository extends JpaRepository<Document, Long> {

    Optional<Document> findFirstByFileHash(String fileHash);

    Optional<Document> findFirstByOriginalFilenameIgnoreCase(String originalFilename);

    List<Document> findAllByOrderByCreatedAtDesc();

    List<Document> findAllByProcessingStatusIn(Collection<ProcessingStatus> statuses);

    List<Document> findAllByFileHashOrderByIdAsc(String fileHash);

    long countByProcessingStatusIn(Collection<ProcessingStatus> statuses);

    @Query("select d.fileHash from Document d group by d.fileHash having count(d) > 1")
    List<String> findDuplicateHashes();

    /**
     * Atomically moves a document into a processing state unless it is already being processed.
     * Returns 0 when another ingestion currently owns the document.
     */
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update Document d set d.processingStatus = :target, d.processingError = null, d.updatedAt = CURRENT_TIMESTAMP "
            + "where d.id = :id and d.processingStatus not in :busy")
    int claim(@Param("id") Long id, @Param("target") ProcessingStatus target,
              @Param("busy") Collection<ProcessingStatus> busy);
}
