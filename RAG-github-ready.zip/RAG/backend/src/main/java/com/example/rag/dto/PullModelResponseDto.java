package com.example.rag.dto;

public class PullModelResponseDto {
    public String model;
    public String status;

    public PullModelResponseDto(String model, String status) {
        this.model = model;
        this.status = status;
    }
}
