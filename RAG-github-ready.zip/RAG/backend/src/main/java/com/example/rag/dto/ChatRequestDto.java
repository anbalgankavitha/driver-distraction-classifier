package com.example.rag.dto;

public class ChatRequestDto {

    public String question;
    /** Optional. When present the question is a follow-up inside an existing conversation. */
    public String conversationId;
}
