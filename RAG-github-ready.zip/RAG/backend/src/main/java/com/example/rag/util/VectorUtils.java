package com.example.rag.util;

public final class VectorUtils {

    private VectorUtils() {
    }

    /** Formats an embedding as a pgvector text literal, e.g. "[0.1,0.2,0.3]". */
    public static String toLiteral(float[] vector) {
        StringBuilder sb = new StringBuilder(vector.length * 10 + 2);
        sb.append('[');
        for (int i = 0; i < vector.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(vector[i]);
        }
        return sb.append(']').toString();
    }
}
