package com.example.rag.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class SyncIssueDto {

    public static final String MISSING_FILE = "MISSING_FILE";
    public static final String ORPHANED_FILE = "ORPHANED_FILE";
    public static final String MISSING_CHUNKS = "MISSING_CHUNKS";
    public static final String INCOMPLETE_EMBEDDINGS = "INCOMPLETE_EMBEDDINGS";
    public static final String DUPLICATE_RECORD = "DUPLICATE_RECORD";
    public static final String CHANGED_HASH = "CHANGED_HASH";
    public static final String OUTDATED_MODEL = "OUTDATED_MODEL";
    public static final String STALE_CHUNKS = "STALE_CHUNKS";

    public String type;
    public Long documentId;
    public String filename;
    public String detail;
    /** Internal reference used by repair (full path of an orphaned file). Never serialised to clients. */
    @JsonIgnore
    public String reference;

    public SyncIssueDto(String type, Long documentId, String filename, String detail, String reference) {
        this.type = type;
        this.documentId = documentId;
        this.filename = filename;
        this.detail = detail;
        this.reference = reference;
    }
}
