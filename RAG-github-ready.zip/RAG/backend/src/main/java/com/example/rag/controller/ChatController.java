package com.example.rag.controller;

import com.example.rag.dto.ChatRequestDto;
import com.example.rag.dto.ChatResponseDto;
import com.example.rag.dto.ConversationDto;
import com.example.rag.service.ChatService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ChatService service;

    public ChatController(ChatService service) {
        this.service = service;
    }

    @PostMapping("/ask")
    public ChatResponseDto ask(@RequestBody ChatRequestDto request) {
        return service.ask(request);
    }

    @GetMapping("/history")
    public List<ConversationDto> history() {
        return service.history();
    }

    @GetMapping("/{conversationId}")
    public ConversationDto get(@PathVariable String conversationId) {
        return service.get(conversationId);
    }

    @DeleteMapping("/{conversationId}")
    public ResponseEntity<Void> delete(@PathVariable String conversationId) {
        service.delete(conversationId);
        return ResponseEntity.noContent().build();
    }
}
