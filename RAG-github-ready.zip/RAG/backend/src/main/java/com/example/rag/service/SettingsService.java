package com.example.rag.service;

import com.example.rag.dto.SettingsDto;
import com.example.rag.entity.AppSetting;
import com.example.rag.exception.BadRequestException;
import com.example.rag.repository.AppSettingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Holds runtime-editable settings. Defaults come from application.yml, overrides are persisted in app_settings.
 */
@Service
public class SettingsService {

    private static final Logger log = LoggerFactory.getLogger(SettingsService.class);

    private final AppSettingRepository repository;

    @Value("${app.ollama.base-url}") private String defaultOllamaUrl;
    @Value("${app.ollama.chat-model}") private String defaultChatModel;
    @Value("${app.ollama.embedding-model}") private String defaultEmbeddingModel;
    @Value("${app.chunking.size}") private int defaultChunkSize;
    @Value("${app.chunking.overlap}") private int defaultChunkOverlap;
    @Value("${app.retrieval.top-k}") private int defaultTopK;
    @Value("${app.retrieval.similarity-threshold}") private double defaultThreshold;
    @Value("${app.storage.location}") private String defaultStorageLocation;
    @Value("${app.storage.max-upload-size-mb}") private int defaultMaxUploadMb;
    @Value("${app.embedding-dimensions}") private int embeddingDimensions;

    private volatile SettingsDto current;

    public SettingsService(AppSettingRepository repository) {
        this.repository = repository;
    }

    @PostConstruct
    void init() {
        SettingsDto settings = defaults();
        try {
            Map<String, String> stored = new HashMap<>();
            for (AppSetting s : repository.findAll()) {
                stored.put(s.getKey(), s.getValue());
            }
            apply(settings, stored);
        } catch (RuntimeException e) {
            log.warn("Could not load persisted settings, using defaults: {}", e.getClass().getSimpleName());
        }
        this.current = settings;
    }

    /** Returns an immutable-by-convention snapshot; callers must not retain it across requests. */
    public SettingsDto snapshot() {
        return current.copy();
    }

    public synchronized SettingsDto update(SettingsDto request) {
        if (request == null) {
            throw new BadRequestException("Settings body is required.");
        }
        SettingsDto merged = request.copy();
        merged.embeddingDimensions = embeddingDimensions;
        merged.ollamaUrl = trimTrailingSlash(trim(merged.ollamaUrl));
        merged.chatModel = trim(merged.chatModel);
        merged.embeddingModel = trim(merged.embeddingModel);
        merged.storageLocation = trim(merged.storageLocation);
        validate(merged);

        Map<String, String> values = new HashMap<>();
        values.put("ollamaUrl", merged.ollamaUrl);
        values.put("chatModel", merged.chatModel);
        values.put("embeddingModel", merged.embeddingModel);
        values.put("chunkSize", String.valueOf(merged.chunkSize));
        values.put("chunkOverlap", String.valueOf(merged.chunkOverlap));
        values.put("topK", String.valueOf(merged.topK));
        values.put("similarityThreshold", String.valueOf(merged.similarityThreshold));
        values.put("storageLocation", merged.storageLocation);
        values.put("maxUploadSizeMb", String.valueOf(merged.maxUploadSizeMb));
        for (Map.Entry<String, String> e : values.entrySet()) {
            repository.save(new AppSetting(e.getKey(), e.getValue()));
        }
        this.current = merged;
        return merged.copy();
    }

    private SettingsDto defaults() {
        SettingsDto s = new SettingsDto();
        s.ollamaUrl = trimTrailingSlash(defaultOllamaUrl);
        s.chatModel = defaultChatModel;
        s.embeddingModel = defaultEmbeddingModel;
        s.chunkSize = defaultChunkSize;
        s.chunkOverlap = defaultChunkOverlap;
        s.topK = defaultTopK;
        s.similarityThreshold = defaultThreshold;
        s.storageLocation = defaultStorageLocation;
        s.maxUploadSizeMb = defaultMaxUploadMb;
        s.embeddingDimensions = embeddingDimensions;
        return s;
    }

    private void apply(SettingsDto s, Map<String, String> stored) {
        try {
            if (stored.containsKey("ollamaUrl")) s.ollamaUrl = stored.get("ollamaUrl");
            if (stored.containsKey("chatModel")) s.chatModel = stored.get("chatModel");
            if (stored.containsKey("embeddingModel")) s.embeddingModel = stored.get("embeddingModel");
            if (stored.containsKey("chunkSize")) s.chunkSize = Integer.parseInt(stored.get("chunkSize"));
            if (stored.containsKey("chunkOverlap")) s.chunkOverlap = Integer.parseInt(stored.get("chunkOverlap"));
            if (stored.containsKey("topK")) s.topK = Integer.parseInt(stored.get("topK"));
            if (stored.containsKey("similarityThreshold")) {
                s.similarityThreshold = Double.parseDouble(stored.get("similarityThreshold"));
            }
            if (stored.containsKey("storageLocation")) s.storageLocation = stored.get("storageLocation");
            if (stored.containsKey("maxUploadSizeMb")) s.maxUploadSizeMb = Integer.parseInt(stored.get("maxUploadSizeMb"));
        } catch (NumberFormatException e) {
            log.warn("Ignoring malformed persisted setting; falling back to defaults for remaining values");
        }
    }

    private void validate(SettingsDto s) {
        try {
            URI uri = URI.create(s.ollamaUrl == null ? "" : s.ollamaUrl);
            if (uri.getHost() == null || !("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()))) {
                throw new BadRequestException("Ollama URL must be a valid http(s) URL.");
            }
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Ollama URL must be a valid http(s) URL.");
        }
        require(s.chatModel, "Chat model");
        require(s.embeddingModel, "Embedding model");
        if (s.chunkSize < 50 || s.chunkSize > 4000) {
            throw new BadRequestException("Chunk size must be between 50 and 4000 tokens.");
        }
        if (s.chunkOverlap < 0 || s.chunkOverlap >= s.chunkSize) {
            throw new BadRequestException("Chunk overlap must be zero or greater and smaller than the chunk size.");
        }
        if (s.topK < 1 || s.topK > 50) {
            throw new BadRequestException("Top-K must be between 1 and 50.");
        }
        if (s.similarityThreshold < 0 || s.similarityThreshold > 1) {
            throw new BadRequestException("Similarity threshold must be between 0 and 1.");
        }
        if (s.maxUploadSizeMb < 1 || s.maxUploadSizeMb > 512) {
            throw new BadRequestException("Maximum upload size must be between 1 and 512 MB.");
        }
        require(s.storageLocation, "File storage location");
        try {
            Path dir = Paths.get(s.storageLocation).toAbsolutePath().normalize();
            Files.createDirectories(dir);
            if (!Files.isWritable(dir)) {
                throw new BadRequestException("File storage location is not writable.");
            }
        } catch (IOException | RuntimeException e) {
            if (e instanceof BadRequestException) {
                throw (BadRequestException) e;
            }
            throw new BadRequestException("File storage location is invalid or cannot be created.");
        }
    }

    private void require(String value, String label) {
        if (value == null || value.isEmpty()) {
            throw new BadRequestException(label + " is required.");
        }
    }

    private static String trim(String v) {
        return v == null ? null : v.trim();
    }

    private static String trimTrailingSlash(String v) {
        if (v == null) {
            return null;
        }
        String r = v;
        while (r.endsWith("/")) {
            r = r.substring(0, r.length() - 1);
        }
        return r;
    }
}
