package com.example.rag.dto;

public class UploadResultDto {

    /** ACCEPTED, REPLACED, DUPLICATE or REJECTED. */
    public String outcome;
    public String filename;
    public String message;
    public DocumentDto document;

    public UploadResultDto(String outcome, String filename, String message, DocumentDto document) {
        this.outcome = outcome;
        this.filename = filename;
        this.message = message;
        this.document = document;
    }
}
