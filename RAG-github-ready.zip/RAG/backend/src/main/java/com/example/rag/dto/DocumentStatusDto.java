package com.example.rag.dto;

import com.example.rag.entity.JobStatus;
import com.example.rag.entity.ProcessingStatus;

import java.time.LocalDateTime;

public class DocumentStatusDto {

    public Long documentId;
    public ProcessingStatus processingStatus;
    public int totalChunks;
    public String processingError;
    public JobStatus latestJobStatus;
    public LocalDateTime latestJobStartedAt;
    public LocalDateTime latestJobCompletedAt;
}
