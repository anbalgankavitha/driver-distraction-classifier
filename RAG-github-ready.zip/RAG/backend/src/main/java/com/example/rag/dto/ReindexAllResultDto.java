package com.example.rag.dto;

import java.util.ArrayList;
import java.util.List;

public class ReindexAllResultDto {

    public int total;
    public int queued;
    public int failed;
    public List<Failure> failures = new ArrayList<>();

    public static class Failure {
        public Long documentId;
        public String filename;
        public String reason;

        public Failure(Long documentId, String filename, String reason) {
            this.documentId = documentId;
            this.filename = filename;
            this.reason = reason;
        }
    }
}
