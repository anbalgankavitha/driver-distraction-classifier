package com.example.rag.service;

import com.example.rag.dto.SettingsDto;
import com.example.rag.dto.SourceDto;
import com.example.rag.repository.ChunkRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Semantic retrieval across all indexed documents: embed, search, threshold, de-duplicate, Top-K. */
@Service
public class RetrievalService {

    private static final double REDUNDANCY_THRESHOLD = 0.85;

    private final OllamaClient ollama;
    private final ChunkRepository chunks;
    private final SettingsService settings;

    @Value("${app.retrieval.candidate-multiplier:4}")
    private int candidateMultiplier;

    public RetrievalService(OllamaClient ollama, ChunkRepository chunks, SettingsService settings) {
        this.ollama = ollama;
        this.chunks = chunks;
        this.settings = settings;
    }

    public List<SourceDto> retrieve(String query) {
        SettingsDto cfg = settings.snapshot();
        float[] embedding = ollama.embed(query, cfg.embeddingModel);
        List<SourceDto> candidates = chunks.search(embedding, cfg.embeddingModel, cfg.topK * Math.max(1, candidateMultiplier));

        List<SourceDto> selected = new ArrayList<>();
        List<Set<String>> selectedWords = new ArrayList<>();
        for (SourceDto candidate : candidates) {
            if (candidate.similarity < cfg.similarityThreshold) {
                continue;
            }
            Set<String> words = wordSet(candidate.text);
            if (isRedundant(words, selectedWords)) {
                continue;
            }
            selected.add(candidate);
            selectedWords.add(words);
            if (selected.size() >= cfg.topK) {
                break;
            }
        }
        return selected;
    }

    private static boolean isRedundant(Set<String> words, List<Set<String>> existing) {
        for (Set<String> other : existing) {
            if (jaccard(words, other) >= REDUNDANCY_THRESHOLD) {
                return true;
            }
        }
        return false;
    }

    private static Set<String> wordSet(String text) {
        Set<String> set = new HashSet<>();
        for (String w : text.toLowerCase(Locale.ROOT).split("\\W+")) {
            if (!w.isEmpty()) {
                set.add(w);
            }
        }
        return set;
    }

    private static double jaccard(Set<String> a, Set<String> b) {
        if (a.isEmpty() || b.isEmpty()) {
            return 0;
        }
        int intersection = 0;
        for (String w : a) {
            if (b.contains(w)) {
                intersection++;
            }
        }
        return (double) intersection / (a.size() + b.size() - intersection);
    }
}
