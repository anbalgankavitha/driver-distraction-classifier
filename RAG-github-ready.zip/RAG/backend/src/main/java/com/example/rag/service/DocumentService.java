package com.example.rag.service;

import com.example.rag.dto.ChunkDto;
import com.example.rag.dto.DocumentDto;
import com.example.rag.dto.DocumentStatusDto;
import com.example.rag.dto.ReindexAllResultDto;
import com.example.rag.dto.UploadResultDto;
import com.example.rag.entity.Document;
import com.example.rag.entity.IngestionJob;
import com.example.rag.entity.ProcessingStatus;
import com.example.rag.exception.ApiException;
import com.example.rag.exception.BadRequestException;
import com.example.rag.exception.NotFoundException;
import com.example.rag.model.StoredFile;
import com.example.rag.repository.ChunkRepository;
import com.example.rag.repository.DocumentRepository;
import com.example.rag.repository.IngestionJobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** Document lifecycle: upload, replace, delete, reindex and read access. */
@Service
public class DocumentService {

    private static final Logger log = LoggerFactory.getLogger(DocumentService.class);

    private final DocumentRepository documents;
    private final IngestionJobRepository jobs;
    private final ChunkRepository chunks;
    private final FileStorageService storage;
    private final IngestionService ingestion;
    private final TransactionTemplate tx;

    public DocumentService(DocumentRepository documents, IngestionJobRepository jobs, ChunkRepository chunks,
                           FileStorageService storage, IngestionService ingestion,
                           PlatformTransactionManager transactionManager) {
        this.documents = documents;
        this.jobs = jobs;
        this.chunks = chunks;
        this.storage = storage;
        this.ingestion = ingestion;
        this.tx = new TransactionTemplate(transactionManager);
    }

    public UploadResultDto upload(MultipartFile file) {
        return handleUpload(file, null);
    }

    /** Uploads several files; a problem with one file never prevents the others from being processed. */
    public List<UploadResultDto> uploadMultiple(List<MultipartFile> files) {
        if (files == null || files.isEmpty()) {
            throw new BadRequestException("No files were provided.");
        }
        List<UploadResultDto> results = new ArrayList<>();
        for (MultipartFile file : files) {
            String name = file.getOriginalFilename();
            try {
                results.add(handleUpload(file, null));
            } catch (ApiException e) {
                results.add(new UploadResultDto("REJECTED", name, e.getMessage(), null));
            }
        }
        return results;
    }

    /** Replaces the content of an existing document; the current index stays live until the new one is ready. */
    public UploadResultDto replace(Long id, MultipartFile file) {
        Document target = find(id);
        return handleUpload(file, target);
    }

    public List<DocumentDto> list() {
        return documents.findAllByOrderByCreatedAtDesc().stream().map(DocumentDto::from).collect(Collectors.toList());
    }

    public DocumentDto get(Long id) {
        return DocumentDto.from(find(id));
    }

    public List<ChunkDto> chunks(Long id) {
        find(id);
        return chunks.findActiveByDocument(id);
    }

    public DocumentStatusDto status(Long id) {
        Document doc = find(id);
        DocumentStatusDto dto = new DocumentStatusDto();
        dto.documentId = doc.getId();
        dto.processingStatus = doc.getProcessingStatus();
        dto.totalChunks = doc.getTotalChunks();
        dto.processingError = doc.getProcessingError();
        Optional<IngestionJob> job = jobs.findFirstByDocumentIdOrderByIdDesc(id);
        if (job.isPresent()) {
            dto.latestJobStatus = job.get().getJobStatus();
            dto.latestJobStartedAt = job.get().getStartedAt();
            dto.latestJobCompletedAt = job.get().getCompletedAt();
        }
        return dto;
    }

    /** Removes the document, its chunks/embeddings and ingestion jobs in one transaction, then its physical file. */
    public void delete(Long id) {
        Document doc = find(id);
        String path = doc.getFilePath();
        tx.execute(status -> {
            // chunks and ingestion jobs are removed by ON DELETE CASCADE in the same transaction
            documents.deleteById(id);
            return null;
        });
        storage.deleteQuietly(path);
        log.info("Deleted document {}", id);
    }

    public DocumentDto reindex(Long id) {
        Document doc = find(id);
        if (!storage.exists(doc.getFilePath())) {
            throw new BadRequestException("The physical file for this document is missing. Re-upload it or delete the record.");
        }
        return DocumentDto.from(ingestion.submit(id, null));
    }

    public ReindexAllResultDto reindexAll() {
        ReindexAllResultDto result = new ReindexAllResultDto();
        List<Document> all = documents.findAllByOrderByCreatedAtDesc();
        result.total = all.size();
        for (Document doc : all) {
            if (!storage.exists(doc.getFilePath())) {
                fail(result, doc, "The physical file is missing.");
                continue;
            }
            try {
                ingestion.submit(doc.getId(), null);
                result.queued++;
            } catch (ApiException e) {
                fail(result, doc, e.getMessage());
            }
        }
        return result;
    }

    private void fail(ReindexAllResultDto result, Document doc, String reason) {
        result.failed++;
        result.failures.add(new ReindexAllResultDto.Failure(doc.getId(), doc.getOriginalFilename(), reason));
    }

    private UploadResultDto handleUpload(MultipartFile file, Document target) {
        StoredFile stored = storage.store(file);
        boolean ownedByDocument = false;
        try {
            Optional<Document> sameContent = documents.findFirstByFileHash(stored.getHash());
            if (sameContent.isPresent()) {
                Document existing = sameContent.get();
                return new UploadResultDto("DUPLICATE", stored.getOriginalFilename(),
                        "Identical content is already indexed as '" + existing.getOriginalFilename() + "'.",
                        DocumentDto.from(existing));
            }

            Document existing = target != null ? target
                    : documents.findFirstByOriginalFilenameIgnoreCase(stored.getOriginalFilename()).orElse(null);
            if (existing != null) {
                Document updated = ingestion.submit(existing.getId(), stored);
                ownedByDocument = true;
                return new UploadResultDto("REPLACED", stored.getOriginalFilename(),
                        "Existing document is being re-indexed with the new content.", DocumentDto.from(updated));
            }

            Document doc = new Document();
            doc.setOriginalFilename(stored.getOriginalFilename());
            doc.setStoredFilename(stored.getStoredFilename());
            doc.setFileType(stored.getFileType());
            doc.setFilePath(stored.getPath().toString());
            doc.setFileSize(stored.getSize());
            doc.setFileHash(stored.getHash());
            doc.setProcessingStatus(ProcessingStatus.UPLOADED);
            doc = documents.save(doc);
            ownedByDocument = true;
            Document queued = ingestion.submit(doc.getId(), null);
            return new UploadResultDto("ACCEPTED", stored.getOriginalFilename(),
                    "Upload accepted and queued for indexing.", DocumentDto.from(queued));
        } finally {
            if (!ownedByDocument) {
                storage.deleteQuietly(stored.getPath());
            }
        }
    }

    private Document find(Long id) {
        return documents.findById(id).orElseThrow(() -> new NotFoundException("Document " + id + " was not found."));
    }
}
