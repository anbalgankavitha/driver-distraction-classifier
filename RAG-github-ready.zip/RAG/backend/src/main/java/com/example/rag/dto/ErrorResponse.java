package com.example.rag.dto;

import java.time.LocalDateTime;

public class ErrorResponse {

    public LocalDateTime timestamp = LocalDateTime.now();
    public int status;
    public String error;
    public String message;

    public ErrorResponse(int status, String error, String message) {
        this.status = status;
        this.error = error;
        this.message = message;
    }
}
