package com.example.rag.dto;

public class SourceDto {

    public Long chunkId;
    public Long documentId;
    public String documentName;
    public Integer pageNumber;
    public String sectionTitle;
    public int chunkIndex;
    public double similarity;
    public String text;
}
