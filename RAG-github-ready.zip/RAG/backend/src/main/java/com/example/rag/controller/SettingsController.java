package com.example.rag.controller;

import com.example.rag.dto.SettingsDto;
import com.example.rag.service.SettingsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/settings")
public class SettingsController {

    private final SettingsService service;

    public SettingsController(SettingsService service) {
        this.service = service;
    }

    @GetMapping
    public SettingsDto get() {
        return service.snapshot();
    }

    @PutMapping
    public SettingsDto update(@RequestBody SettingsDto settings) {
        return service.update(settings);
    }
}
