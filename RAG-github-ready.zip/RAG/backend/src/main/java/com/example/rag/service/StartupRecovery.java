package com.example.rag.service;

import com.example.rag.entity.Document;
import com.example.rag.entity.IngestionJob;
import com.example.rag.entity.JobStatus;
import com.example.rag.entity.ProcessingStatus;
import com.example.rag.repository.DocumentRepository;
import com.example.rag.repository.IngestionJobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;

/** Marks work that was interrupted by a restart as failed so it can be re-run instead of staying "processing". */
@Component
public class StartupRecovery {

    private static final Logger log = LoggerFactory.getLogger(StartupRecovery.class);

    private final DocumentRepository documents;
    private final IngestionJobRepository jobs;

    public StartupRecovery(DocumentRepository documents, IngestionJobRepository jobs) {
        this.documents = documents;
        this.jobs = jobs;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void recover() {
        try {
            for (Document doc : documents.findAllByProcessingStatusIn(Arrays.asList(
                    ProcessingStatus.PROCESSING, ProcessingStatus.REINDEXING, ProcessingStatus.UPLOADED))) {
                doc.setProcessingStatus(ProcessingStatus.FAILED);
                doc.setProcessingError("Processing was interrupted by an application restart. Re-index the document.");
                documents.save(doc);
            }
            for (IngestionJob job : jobs.findAllByJobStatusIn(Arrays.asList(JobStatus.QUEUED, JobStatus.RUNNING))) {
                job.setJobStatus(JobStatus.FAILED);
                job.setErrorMessage("Interrupted by application restart");
                job.setCompletedAt(LocalDateTime.now());
                jobs.save(job);
            }
        } catch (RuntimeException e) {
            log.warn("Startup recovery skipped: {}", e.getClass().getSimpleName());
        }
    }
}
