package com.example.rag.dto;

import java.util.ArrayList;
import java.util.List;

public class OllamaStatusDto {

    public boolean reachable;
    public String url;
    public String message;
    public String chatModel;
    public String embeddingModel;
    public boolean chatModelAvailable;
    public boolean embeddingModelAvailable;
    public List<OllamaModelDto> models = new ArrayList<>();
}
