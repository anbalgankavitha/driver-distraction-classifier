package com.example.rag.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SyncReportDto {

    public LocalDateTime checkedAt = LocalDateTime.now();
    public int documentsChecked;
    public List<SyncIssueDto> issues = new ArrayList<>();
    public boolean consistent;
}
