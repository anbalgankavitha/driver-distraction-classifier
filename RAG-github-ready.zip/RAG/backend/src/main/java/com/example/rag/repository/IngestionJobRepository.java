package com.example.rag.repository;

import com.example.rag.entity.IngestionJob;
import com.example.rag.entity.JobStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface IngestionJobRepository extends JpaRepository<IngestionJob, Long> {

    Optional<IngestionJob> findFirstByDocumentIdOrderByIdDesc(Long documentId);

    List<IngestionJob> findAllByJobStatusIn(Collection<JobStatus> statuses);
}
