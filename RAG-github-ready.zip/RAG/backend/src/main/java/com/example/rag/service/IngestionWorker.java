package com.example.rag.service;

import com.example.rag.dto.SettingsDto;
import com.example.rag.entity.Document;
import com.example.rag.entity.IngestionJob;
import com.example.rag.entity.JobStatus;
import com.example.rag.entity.ProcessingStatus;
import com.example.rag.exception.IngestionException;
import com.example.rag.model.ExtractedSection;
import com.example.rag.model.StoredFile;
import com.example.rag.model.TextChunk;
import com.example.rag.repository.ChunkRepository;
import com.example.rag.repository.DocumentRepository;
import com.example.rag.repository.IngestionJobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Background ingestion: extract, chunk, embed, then atomically swap the new index version in.
 * The previous index stays searchable until the new version has been fully written and validated, and a failure
 * at any point leaves the existing index untouched.
 */
@Component
public class IngestionWorker {

    private static final Logger log = LoggerFactory.getLogger(IngestionWorker.class);
    private static final int MAX_ERROR_LENGTH = 1000;

    private final DocumentRepository documents;
    private final IngestionJobRepository jobs;
    private final ChunkRepository chunks;
    private final TextExtractor extractor;
    private final TextChunker chunker;
    private final OllamaClient ollama;
    private final SettingsService settings;
    private final FileStorageService storage;
    private final TransactionTemplate tx;

    public IngestionWorker(DocumentRepository documents, IngestionJobRepository jobs, ChunkRepository chunks,
                           TextExtractor extractor, TextChunker chunker, OllamaClient ollama,
                           SettingsService settings, FileStorageService storage,
                           PlatformTransactionManager transactionManager) {
        this.documents = documents;
        this.jobs = jobs;
        this.chunks = chunks;
        this.extractor = extractor;
        this.chunker = chunker;
        this.ollama = ollama;
        this.settings = settings;
        this.storage = storage;
        this.tx = new TransactionTemplate(transactionManager);
    }

    /**
     * @param replacement optional new file that replaces the document's current file once indexing succeeds
     */
    @Async("ingestionExecutor")
    public void process(Long documentId, Long jobId, StoredFile replacement) {
        updateJob(jobId, JobStatus.RUNNING, null);
        String previousPath = null;
        try {
            Document doc = documents.findById(documentId)
                    .orElseThrow(() -> new IngestionException("The document no longer exists."));
            previousPath = doc.getFilePath();

            Path file = replacement != null ? replacement.getPath() : Paths.get(doc.getFilePath());
            String fileType = replacement != null ? replacement.getFileType() : doc.getFileType();
            if (!Files.isRegularFile(file)) {
                throw new IngestionException("The physical file is missing from storage.");
            }
            String hash = replacement != null ? replacement.getHash() : FileStorageService.sha256(file);

            SettingsDto cfg = settings.snapshot();
            List<ExtractedSection> sections = extractor.extract(file, fileType);
            List<TextChunk> textChunks = chunker.chunk(sections, cfg.chunkSize, cfg.chunkOverlap);
            if (textChunks.isEmpty()) {
                throw new IngestionException("The document produced no chunks.");
            }

            List<String> texts = new ArrayList<>(textChunks.size());
            for (TextChunk c : textChunks) {
                texts.add(c.getText());
            }
            List<float[]> embeddings = ollama.embedAll(texts, cfg.embeddingModel);
            validateEmbeddings(embeddings, textChunks.size(), cfg.embeddingDimensions);

            commitNewVersion(documentId, textChunks, embeddings, cfg.embeddingModel, hash, replacement);
            updateJob(jobId, JobStatus.COMPLETED, null);

            if (replacement != null && previousPath != null && !previousPath.equals(replacement.getPath().toString())) {
                storage.deleteQuietly(previousPath);
            }
            log.info("Indexed document {} with {} chunks", documentId, textChunks.size());
        } catch (Exception e) {
            String message = describe(e);
            log.error("Indexing failed for document {}: {}", documentId, message);
            if (replacement != null) {
                storage.deleteQuietly(replacement.getPath());
            }
            markFailed(documentId, message);
            updateJob(jobId, JobStatus.FAILED, message);
        }
    }

    private void commitNewVersion(Long documentId, List<TextChunk> textChunks, List<float[]> embeddings,
                                  String model, String hash, StoredFile replacement) {
        tx.execute(status -> {
            Document doc = documents.findById(documentId)
                    .orElseThrow(() -> new IngestionException("The document was deleted during indexing."));
            int newVersion = doc.getActiveVersion() + 1;
            chunks.insertBatch(documentId, newVersion, textChunks, embeddings);
            if (chunks.countVersion(documentId, newVersion) != textChunks.size()) {
                throw new IngestionException("Index validation failed: stored chunk count does not match.");
            }
            doc.setActiveVersion(newVersion);
            doc.setTotalChunks(textChunks.size());
            doc.setEmbeddingModel(model);
            doc.setFileHash(hash);
            doc.setLastIndexedAt(LocalDateTime.now());
            doc.setProcessingError(null);
            doc.setProcessingStatus(ProcessingStatus.COMPLETED);
            if (replacement != null) {
                doc.setOriginalFilename(replacement.getOriginalFilename());
                doc.setStoredFilename(replacement.getStoredFilename());
                doc.setFilePath(replacement.getPath().toString());
                doc.setFileSize(replacement.getSize());
                doc.setFileType(replacement.getFileType());
            }
            documents.save(doc);
            chunks.deleteOtherVersions(documentId, newVersion);
            return null;
        });
    }

    private void validateEmbeddings(List<float[]> embeddings, int expected, int dimensions) {
        if (embeddings.size() != expected) {
            throw new IngestionException("Incomplete embedding generation: expected " + expected
                    + " embeddings but received " + embeddings.size() + ".");
        }
        for (float[] e : embeddings) {
            if (e.length != dimensions) {
                throw new IngestionException("The embedding model returned " + e.length
                        + " dimensions but the database expects " + dimensions
                        + ". Use a matching model or change the vector column dimension.");
            }
        }
    }

    private void markFailed(Long documentId, String message) {
        try {
            tx.execute(status -> {
                documents.findById(documentId).ifPresent(doc -> {
                    String prefix = doc.getActiveVersion() > 0 ? "Re-indexing failed; previous index retained. " : "";
                    doc.setProcessingStatus(ProcessingStatus.FAILED);
                    doc.setProcessingError(truncate(prefix + message));
                    documents.save(doc);
                });
                return null;
            });
        } catch (RuntimeException e) {
            log.error("Could not record failure for document {}: {}", documentId, e.getClass().getSimpleName());
        }
    }

    private void updateJob(Long jobId, JobStatus status, String error) {
        try {
            tx.execute(s -> {
                jobs.findById(jobId).ifPresent(job -> applyJobState(job, status, error));
                return null;
            });
        } catch (RuntimeException e) {
            log.warn("Could not update ingestion job {}: {}", jobId, e.getClass().getSimpleName());
        }
    }

    private void applyJobState(IngestionJob job, JobStatus status, String error) {
        job.setJobStatus(status);
        if (status == JobStatus.RUNNING) {
            job.setStartedAt(LocalDateTime.now());
        } else {
            job.setCompletedAt(LocalDateTime.now());
            job.setErrorMessage(error == null ? null : truncate(error));
        }
        jobs.save(job);
    }

    private static String describe(Exception e) {
        String m = e.getMessage();
        return (m == null || m.isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private static String truncate(String s) {
        return s.length() <= MAX_ERROR_LENGTH ? s : s.substring(0, MAX_ERROR_LENGTH);
    }
}
