package com.example.rag.model;

import java.nio.file.Path;

/** Result of safely storing an uploaded file on local disk. */
public class StoredFile {

    private final String originalFilename;
    private final String storedFilename;
    private final Path path;
    private final long size;
    private final String hash;
    private final String fileType;

    public StoredFile(String originalFilename, String storedFilename, Path path, long size, String hash, String fileType) {
        this.originalFilename = originalFilename;
        this.storedFilename = storedFilename;
        this.path = path;
        this.size = size;
        this.hash = hash;
        this.fileType = fileType;
    }

    public String getOriginalFilename() { return originalFilename; }
    public String getStoredFilename() { return storedFilename; }
    public Path getPath() { return path; }
    public long getSize() { return size; }
    public String getHash() { return hash; }
    public String getFileType() { return fileType; }
}
