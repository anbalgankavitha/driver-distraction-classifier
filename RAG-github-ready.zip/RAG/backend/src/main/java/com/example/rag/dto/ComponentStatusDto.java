package com.example.rag.dto;

public class ComponentStatusDto {

    public boolean up;
    public String message;

    public ComponentStatusDto(boolean up, String message) {
        this.up = up;
        this.message = message;
    }
}
