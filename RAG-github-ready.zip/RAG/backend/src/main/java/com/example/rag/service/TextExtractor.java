package com.example.rag.service;

import com.example.rag.exception.IngestionException;
import com.example.rag.model.ExtractedSection;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Extracts normalized text from TXT, PDF, DOC and DOCX files, keeping page numbers and headings where available. */
@Component
public class TextExtractor {

    public List<ExtractedSection> extract(Path file, String fileType) {
        List<ExtractedSection> raw;
        try {
            switch (fileType.toLowerCase(Locale.ROOT)) {
                case "txt":
                    raw = extractTxt(file);
                    break;
                case "pdf":
                    raw = extractPdf(file);
                    break;
                case "docx":
                    raw = extractDocx(file);
                    break;
                case "doc":
                    raw = extractDoc(file);
                    break;
                default:
                    throw new IngestionException("Unsupported file type: " + fileType);
            }
        } catch (IOException e) {
            throw new IngestionException("The document could not be read: " + e.getMessage(), e);
        }

        List<ExtractedSection> result = new ArrayList<>();
        for (ExtractedSection s : raw) {
            String text = normalize(s.getText());
            if (!text.isEmpty()) {
                result.add(new ExtractedSection(s.getPageNumber(), s.getTitle(), text));
            }
        }
        if (result.isEmpty()) {
            throw new IngestionException("No extractable text was found in the document.");
        }
        return result;
    }

    static String normalize(String text) {
        if (text == null) {
            return "";
        }
        String t = text.replace("\r\n", "\n").replace('\r', '\n').replace(' ', ' ');
        t = t.replaceAll("[\\p{Cntrl}&&[^\\n\\t]]", "");
        t = t.replace('\t', ' ');
        t = t.replaceAll(" {2,}", " ");
        t = t.replaceAll(" ?\\n ?", "\n");
        t = t.replaceAll("\\n{3,}", "\n\n");
        return t.trim();
    }

    private List<ExtractedSection> extractTxt(Path file) throws IOException {
        byte[] bytes = Files.readAllBytes(file);
        String text;
        try {
            text = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException e) {
            text = new String(bytes, Charset.forName("windows-1252"));
        }
        if (text.startsWith("﻿")) {
            text = text.substring(1);
        }
        List<ExtractedSection> sections = new ArrayList<>();
        sections.add(new ExtractedSection(null, null, text));
        return sections;
    }

    private List<ExtractedSection> extractPdf(Path file) throws IOException {
        List<ExtractedSection> sections = new ArrayList<>();
        try (PDDocument pdf = PDDocument.load(file.toFile())) {
            if (pdf.isEncrypted()) {
                throw new IngestionException("The PDF is encrypted and cannot be indexed.");
            }
            PDFTextStripper stripper = new PDFTextStripper();
            int pages = pdf.getNumberOfPages();
            for (int page = 1; page <= pages; page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                sections.add(new ExtractedSection(page, null, stripper.getText(pdf)));
            }
        }
        return sections;
    }

    private List<ExtractedSection> extractDocx(Path file) throws IOException {
        List<ExtractedSection> sections = new ArrayList<>();
        try (InputStream in = Files.newInputStream(file); XWPFDocument doc = new XWPFDocument(in)) {
            String title = null;
            StringBuilder buffer = new StringBuilder();
            for (IBodyElement element : doc.getBodyElements()) {
                if (element instanceof XWPFParagraph) {
                    XWPFParagraph paragraph = (XWPFParagraph) element;
                    String text = paragraph.getText();
                    if (text == null || text.trim().isEmpty()) {
                        continue;
                    }
                    if (isHeading(paragraph)) {
                        flush(sections, title, buffer);
                        title = text.trim();
                        buffer = new StringBuilder();
                    }
                    buffer.append(text.trim()).append("\n\n");
                } else if (element instanceof XWPFTable) {
                    buffer.append(tableToText((XWPFTable) element)).append("\n\n");
                }
            }
            flush(sections, title, buffer);
        }
        return sections;
    }

    private List<ExtractedSection> extractDoc(Path file) throws IOException {
        List<ExtractedSection> sections = new ArrayList<>();
        try (InputStream in = Files.newInputStream(file);
             HWPFDocument doc = new HWPFDocument(in);
             WordExtractor extractor = new WordExtractor(doc)) {
            StringBuilder buffer = new StringBuilder();
            for (String paragraph : extractor.getParagraphText()) {
                String p = paragraph.trim();
                if (!p.isEmpty()) {
                    buffer.append(p).append("\n\n");
                }
            }
            sections.add(new ExtractedSection(null, null, buffer.toString()));
        }
        return sections;
    }

    private static boolean isHeading(XWPFParagraph paragraph) {
        String style = paragraph.getStyle();
        if (style == null) {
            return false;
        }
        String s = style.toLowerCase(Locale.ROOT);
        return s.startsWith("heading") || s.equals("title");
    }

    private static String tableToText(XWPFTable table) {
        StringBuilder sb = new StringBuilder();
        for (XWPFTableRow row : table.getRows()) {
            List<String> cells = new ArrayList<>();
            for (XWPFTableCell cell : row.getTableCells()) {
                cells.add(cell.getText().trim());
            }
            sb.append(String.join(" | ", cells)).append('\n');
        }
        return sb.toString();
    }

    private static void flush(List<ExtractedSection> sections, String title, StringBuilder buffer) {
        if (buffer.toString().trim().length() > 0) {
            sections.add(new ExtractedSection(null, title, buffer.toString()));
        }
    }
}
