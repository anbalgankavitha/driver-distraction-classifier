package com.example.rag.exception;

import org.springframework.http.HttpStatus;

public class OllamaUnavailableException extends ApiException {

    public OllamaUnavailableException(String message, Throwable cause) {
        super(HttpStatus.SERVICE_UNAVAILABLE, message, cause);
    }

    public OllamaUnavailableException(String message) {
        super(HttpStatus.SERVICE_UNAVAILABLE, message);
    }
}
