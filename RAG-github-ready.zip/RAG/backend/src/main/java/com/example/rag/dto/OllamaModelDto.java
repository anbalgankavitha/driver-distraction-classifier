package com.example.rag.dto;

public class OllamaModelDto {

    public String name;
    public long sizeBytes;

    public OllamaModelDto(String name, long sizeBytes) {
        this.name = name;
        this.sizeBytes = sizeBytes;
    }
}
