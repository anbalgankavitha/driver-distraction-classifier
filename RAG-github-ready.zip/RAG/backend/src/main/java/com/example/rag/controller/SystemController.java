package com.example.rag.controller;

import com.example.rag.dto.HealthDto;
import com.example.rag.dto.OllamaModelDto;
import com.example.rag.dto.OllamaStatusDto;
import com.example.rag.dto.PullModelRequestDto;
import com.example.rag.dto.PullModelResponseDto;
import com.example.rag.dto.SyncRepairDto;
import com.example.rag.dto.SyncReportDto;
import com.example.rag.exception.BadRequestException;
import com.example.rag.service.OllamaClient;
import com.example.rag.service.SyncService;
import com.example.rag.service.SystemService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/system")
public class SystemController {

    private final SystemService systemService;
    private final SyncService syncService;
    private final OllamaClient ollama;

    public SystemController(SystemService systemService, SyncService syncService, OllamaClient ollama) {
        this.systemService = systemService;
        this.syncService = syncService;
        this.ollama = ollama;
    }

    @GetMapping("/health")
    public HealthDto health() {
        return systemService.health();
    }

    @GetMapping("/ollama/status")
    public OllamaStatusDto ollamaStatus() {
        return systemService.ollamaStatus();
    }

    @GetMapping("/ollama/models")
    public List<OllamaModelDto> ollamaModels() {
        return ollama.models();
    }

    @PostMapping("/ollama/pull")
    public PullModelResponseDto pullOllamaModel(@RequestBody(required = false) PullModelRequestDto request) {
        if (request == null || request.model == null || request.model.trim().isEmpty()) {
            throw new BadRequestException("A model name is required.");
        }
        String model = request.model.trim();
        if (model.length() > 255 || model.chars().anyMatch(Character::isWhitespace)) {
            throw new BadRequestException("Enter a valid Ollama model name, such as qwen3:8b.");
        }
        ollama.pullModel(model);
        return new PullModelResponseDto(model, "success");
    }

    @PostMapping("/sync/validate")
    public SyncReportDto validate() {
        return syncService.validate();
    }

    @PostMapping("/sync/repair")
    public SyncRepairDto repair() {
        return syncService.repair();
    }
}
