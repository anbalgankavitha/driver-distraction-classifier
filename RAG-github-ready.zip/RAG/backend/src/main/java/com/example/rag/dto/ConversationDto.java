package com.example.rag.dto;

import java.time.LocalDateTime;
import java.util.List;

public class ConversationDto {

    public String id;
    public String title;
    public LocalDateTime createdAt;
    public LocalDateTime updatedAt;
    /** Only populated when a single conversation is requested. */
    public List<ChatMessageDto> messages;
    public long messageCount;
}
