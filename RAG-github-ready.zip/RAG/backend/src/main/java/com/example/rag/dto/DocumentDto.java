package com.example.rag.dto;

import com.example.rag.entity.Document;
import com.example.rag.entity.ProcessingStatus;

import java.time.LocalDateTime;

/** Public view of a document. Internal storage paths are intentionally not exposed. */
public class DocumentDto {

    public Long id;
    public String originalFilename;
    public String fileType;
    public long fileSize;
    public String fileHash;
    public int totalChunks;
    public ProcessingStatus processingStatus;
    public LocalDateTime createdAt;
    public LocalDateTime updatedAt;
    public LocalDateTime lastIndexedAt;
    public String processingError;
    public String embeddingModel;

    public static DocumentDto from(Document d) {
        DocumentDto dto = new DocumentDto();
        dto.id = d.getId();
        dto.originalFilename = d.getOriginalFilename();
        dto.fileType = d.getFileType();
        dto.fileSize = d.getFileSize();
        dto.fileHash = d.getFileHash();
        dto.totalChunks = d.getTotalChunks();
        dto.processingStatus = d.getProcessingStatus();
        dto.createdAt = d.getCreatedAt();
        dto.updatedAt = d.getUpdatedAt();
        dto.lastIndexedAt = d.getLastIndexedAt();
        dto.processingError = d.getProcessingError();
        dto.embeddingModel = d.getEmbeddingModel();
        return dto;
    }
}
