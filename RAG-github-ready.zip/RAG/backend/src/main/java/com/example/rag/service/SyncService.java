package com.example.rag.service;

import com.example.rag.dto.SettingsDto;
import com.example.rag.dto.SyncIssueDto;
import com.example.rag.dto.SyncRepairDto;
import com.example.rag.dto.SyncReportDto;
import com.example.rag.entity.Document;
import com.example.rag.entity.ProcessingStatus;
import com.example.rag.exception.ApiException;
import com.example.rag.repository.ChunkRepository;
import com.example.rag.repository.DocumentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Validates that database records, vector index and physical files agree, and repairs what can be repaired. */
@Service
public class SyncService {

    private static final Logger log = LoggerFactory.getLogger(SyncService.class);

    private final DocumentRepository documents;
    private final ChunkRepository chunks;
    private final FileStorageService storage;
    private final SettingsService settings;
    private final IngestionService ingestion;
    private final DocumentService documentService;

    public SyncService(DocumentRepository documents, ChunkRepository chunks, FileStorageService storage,
                       SettingsService settings, IngestionService ingestion, DocumentService documentService) {
        this.documents = documents;
        this.chunks = chunks;
        this.storage = storage;
        this.settings = settings;
        this.ingestion = ingestion;
        this.documentService = documentService;
    }

    public SyncReportDto validate() {
        SyncReportDto report = new SyncReportDto();
        SettingsDto cfg = settings.snapshot();
        List<Document> all = documents.findAllByOrderByCreatedAtDesc();
        report.documentsChecked = all.size();

        Set<Path> referenced = new HashSet<>();
        for (Document doc : all) {
            referenced.add(FileStorageService.normalize(doc.getFilePath()));
            checkDocument(doc, cfg, report);
        }
        checkDuplicates(report);
        for (Path file : storage.listStoredFiles()) {
            // files written in the last minutes may belong to an upload that has not been registered yet
            if (!referenced.contains(file.toAbsolutePath().normalize()) && !isRecent(file)) {
                report.issues.add(new SyncIssueDto(SyncIssueDto.ORPHANED_FILE, null, file.getFileName().toString(),
                        "File exists in storage but is not registered to any document.", file.toAbsolutePath().toString()));
            }
        }
        report.consistent = report.issues.isEmpty();
        return report;
    }

    public SyncRepairDto repair() {
        SyncReportDto report = validate();
        SyncRepairDto result = new SyncRepairDto();
        result.issuesFound = report.issues.size();
        Set<Long> reindexed = new HashSet<>();

        for (SyncIssueDto issue : report.issues) {
            try {
                String action = repairIssue(issue, reindexed);
                if (action != null) {
                    result.repaired++;
                    result.actions.add(action);
                }
            } catch (ApiException | IllegalStateException e) {
                result.failed++;
                result.actions.add("Could not repair " + issue.type + " for '" + issue.filename + "': " + e.getMessage());
            }
        }
        return result;
    }

    private void checkDocument(Document doc, SettingsDto cfg, SyncReportDto report) {
        if (isBusy(doc)) {
            return;
        }
        boolean fileExists = storage.exists(doc.getFilePath());
        if (!fileExists) {
            report.issues.add(issue(SyncIssueDto.MISSING_FILE, doc, "The physical file is missing from storage."));
        } else {
            try {
                String actual = FileStorageService.sha256(Paths.get(doc.getFilePath()));
                if (!actual.equals(doc.getFileHash())) {
                    report.issues.add(issue(SyncIssueDto.CHANGED_HASH, doc,
                            "The file on disk differs from the content that was indexed."));
                }
            } catch (IOException e) {
                log.warn("Could not hash file of document {}", doc.getId());
            }
        }

        if (doc.getProcessingStatus() == ProcessingStatus.COMPLETED) {
            long active = chunks.countActiveForDocument(doc.getId());
            if (active == 0 || active != doc.getTotalChunks()) {
                report.issues.add(issue(SyncIssueDto.MISSING_CHUNKS, doc,
                        "Expected " + doc.getTotalChunks() + " chunks but found " + active + "."));
            }
            long missingEmbeddings = chunks.countActiveWithoutEmbedding(doc.getId());
            if (missingEmbeddings > 0) {
                report.issues.add(issue(SyncIssueDto.INCOMPLETE_EMBEDDINGS, doc,
                        missingEmbeddings + " chunks have no embedding."));
            }
            if (doc.getEmbeddingModel() != null && !doc.getEmbeddingModel().equals(cfg.embeddingModel)) {
                report.issues.add(issue(SyncIssueDto.OUTDATED_MODEL, doc, "Indexed with '" + doc.getEmbeddingModel()
                        + "' but the current embedding model is '" + cfg.embeddingModel + "'."));
            }
        }
        long stale = chunks.countStaleForDocument(doc.getId());
        if (stale > 0) {
            report.issues.add(issue(SyncIssueDto.STALE_CHUNKS, doc, stale + " superseded chunks remain in the index."));
        }
    }

    private void checkDuplicates(SyncReportDto report) {
        for (String hash : documents.findDuplicateHashes()) {
            List<Document> group = documents.findAllByFileHashOrderByIdAsc(hash);
            for (int i = 1; i < group.size(); i++) {
                Document dup = group.get(i);
                report.issues.add(issue(SyncIssueDto.DUPLICATE_RECORD, dup,
                        "Same content as '" + group.get(0).getOriginalFilename() + "' (id " + group.get(0).getId() + ")."));
            }
        }
    }

    private String repairIssue(SyncIssueDto issue, Set<Long> reindexed) {
        switch (issue.type) {
            case SyncIssueDto.ORPHANED_FILE:
                storage.deleteQuietly(issue.reference);
                return "Deleted orphaned file " + issue.filename;
            case SyncIssueDto.DUPLICATE_RECORD:
                documentService.delete(issue.documentId);
                return "Removed duplicate record '" + issue.filename + "'";
            case SyncIssueDto.STALE_CHUNKS:
                chunks.deleteStaleForDocument(issue.documentId);
                return "Removed superseded chunks of '" + issue.filename + "'";
            case SyncIssueDto.MISSING_FILE:
                Document doc = documents.findById(issue.documentId).orElse(null);
                if (doc != null && doc.getProcessingStatus() != ProcessingStatus.FAILED) {
                    doc.setProcessingStatus(ProcessingStatus.FAILED);
                    doc.setProcessingError("The physical file is missing. Re-upload the document or delete the record.");
                    documents.save(doc);
                    return "Marked '" + issue.filename + "' as FAILED because its file is missing";
                }
                return null;
            default:
                if (!reindexed.add(issue.documentId)) {
                    return null;
                }
                ingestion.submit(issue.documentId, null);
                return "Queued re-indexing of '" + issue.filename + "' (" + issue.type + ")";
        }
    }

    private static boolean isRecent(Path file) {
        try {
            return System.currentTimeMillis() - Files.getLastModifiedTime(file).toMillis() < 5 * 60 * 1000L;
        } catch (IOException e) {
            return true;
        }
    }

    private static boolean isBusy(Document doc) {
        return doc.getProcessingStatus() == ProcessingStatus.PROCESSING
                || doc.getProcessingStatus() == ProcessingStatus.REINDEXING
                || doc.getProcessingStatus() == ProcessingStatus.UPLOADED;
    }

    private static SyncIssueDto issue(String type, Document doc, String detail) {
        return new SyncIssueDto(type, doc.getId(), doc.getOriginalFilename(), detail, null);
    }
}
