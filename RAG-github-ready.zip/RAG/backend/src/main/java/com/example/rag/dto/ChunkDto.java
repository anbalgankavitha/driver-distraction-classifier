package com.example.rag.dto;

public class ChunkDto {

    public Long id;
    public int chunkIndex;
    public String text;
    public Integer pageNumber;
    public String sectionTitle;
}
