package com.example.rag.dto;

public class DashboardStatsDto {

    public long totalDocuments;
    public long completedDocuments;
    public long processingDocuments;
    public long failedDocuments;
    public long totalChunks;
}
