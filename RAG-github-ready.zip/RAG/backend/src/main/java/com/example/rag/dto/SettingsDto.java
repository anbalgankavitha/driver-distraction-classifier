package com.example.rag.dto;

public class SettingsDto {

    public String ollamaUrl;
    public String chatModel;
    public String embeddingModel;
    public int chunkSize;
    public int chunkOverlap;
    public int topK;
    public double similarityThreshold;
    public String storageLocation;
    public int maxUploadSizeMb;
    /** Read-only: fixed by the pgvector column definition. */
    public int embeddingDimensions;

    public SettingsDto copy() {
        SettingsDto c = new SettingsDto();
        c.ollamaUrl = ollamaUrl;
        c.chatModel = chatModel;
        c.embeddingModel = embeddingModel;
        c.chunkSize = chunkSize;
        c.chunkOverlap = chunkOverlap;
        c.topK = topK;
        c.similarityThreshold = similarityThreshold;
        c.storageLocation = storageLocation;
        c.maxUploadSizeMb = maxUploadSizeMb;
        c.embeddingDimensions = embeddingDimensions;
        return c;
    }
}
