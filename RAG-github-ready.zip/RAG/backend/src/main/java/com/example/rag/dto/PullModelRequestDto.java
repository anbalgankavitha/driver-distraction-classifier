package com.example.rag.dto;

public class PullModelRequestDto {
    public String model;
}
