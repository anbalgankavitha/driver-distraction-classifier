package com.example.rag.entity;

public enum JobStatus {
    QUEUED,
    RUNNING,
    COMPLETED,
    FAILED
}
