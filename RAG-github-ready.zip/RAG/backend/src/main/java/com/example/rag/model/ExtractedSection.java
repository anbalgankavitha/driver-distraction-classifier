package com.example.rag.model;

/** A contiguous block of extracted text (a PDF page, a DOCX heading section, or a whole plain document). */
public class ExtractedSection {

    private final Integer pageNumber;
    private final String title;
    private final String text;

    public ExtractedSection(Integer pageNumber, String title, String text) {
        this.pageNumber = pageNumber;
        this.title = title;
        this.text = text;
    }

    public Integer getPageNumber() { return pageNumber; }
    public String getTitle() { return title; }
    public String getText() { return text; }
}
