package com.example.rag.controller;

import com.example.rag.dto.ChunkDto;
import com.example.rag.dto.DocumentDto;
import com.example.rag.dto.DocumentStatusDto;
import com.example.rag.dto.ReindexAllResultDto;
import com.example.rag.dto.UploadResultDto;
import com.example.rag.service.DocumentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private final DocumentService service;

    public DocumentController(DocumentService service) {
        this.service = service;
    }

    @PostMapping("/upload")
    public ResponseEntity<UploadResultDto> upload(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(service.upload(file));
    }

    @PostMapping("/upload/multiple")
    public ResponseEntity<List<UploadResultDto>> uploadMultiple(@RequestParam("files") List<MultipartFile> files) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(service.uploadMultiple(files));
    }

    /** Replaces the content of an existing document with a new file. */
    @PutMapping("/{id}")
    public ResponseEntity<UploadResultDto> replace(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(service.replace(id, file));
    }

    @GetMapping
    public List<DocumentDto> list() {
        return service.list();
    }

    @GetMapping("/{id}")
    public DocumentDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/reindex")
    public ResponseEntity<DocumentDto> reindex(@PathVariable Long id) {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(service.reindex(id));
    }

    @PostMapping("/reindex-all")
    public ResponseEntity<ReindexAllResultDto> reindexAll() {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(service.reindexAll());
    }

    @GetMapping("/{id}/chunks")
    public List<ChunkDto> chunks(@PathVariable Long id) {
        return service.chunks(id);
    }

    @GetMapping("/{id}/status")
    public DocumentStatusDto status(@PathVariable Long id) {
        return service.status(id);
    }
}
