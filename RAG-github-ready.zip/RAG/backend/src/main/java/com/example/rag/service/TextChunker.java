package com.example.rag.service;

import com.example.rag.model.ExtractedSection;
import com.example.rag.model.TextChunk;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Splits sections into overlapping chunks. Tokens are approximated by whitespace-separated words.
 * Paragraph boundaries are preserved: paragraphs are packed whole into a chunk, and only a paragraph that is
 * itself larger than the chunk size is split. Chunks never span sections, so page numbers stay accurate.
 */
@Component
public class TextChunker {

    public List<TextChunk> chunk(List<ExtractedSection> sections, int chunkSize, int overlap) {
        int size = Math.max(1, chunkSize);
        int safeOverlap = Math.max(0, Math.min(overlap, size - 1));
        List<TextChunk> result = new ArrayList<>();
        for (ExtractedSection section : sections) {
            chunkSection(section, size, safeOverlap, result);
        }
        return result;
    }

    private void chunkSection(ExtractedSection section, int size, int overlap, List<TextChunk> out) {
        List<String> units = toUnits(section.getText(), size, overlap);
        StringBuilder current = new StringBuilder();
        int currentTokens = 0;
        boolean hasNewContent = false;

        for (String unit : units) {
            int unitTokens = countTokens(unit);
            if (hasNewContent && currentTokens + unitTokens > size) {
                String finished = current.toString();
                emit(out, section, finished);
                int carry = Math.min(overlap, Math.max(0, size - unitTokens));
                String tail = tail(finished, carry);
                current = new StringBuilder(tail);
                currentTokens = tail.isEmpty() ? 0 : countTokens(tail);
                hasNewContent = false;
            }
            if (current.length() > 0) {
                current.append("\n\n");
            }
            current.append(unit);
            currentTokens += unitTokens;
            hasNewContent = true;
        }
        if (hasNewContent) {
            emit(out, section, current.toString());
        }
    }

    /** Paragraphs that fit in a chunk are kept whole; larger ones are split into overlapping word windows. */
    private List<String> toUnits(String text, int size, int overlap) {
        List<String> units = new ArrayList<>();
        for (String paragraph : text.split("\\n\\s*\\n")) {
            String p = paragraph.trim();
            if (p.isEmpty()) {
                continue;
            }
            String[] words = p.split("\\s+");
            if (words.length <= size) {
                units.add(p);
                continue;
            }
            int step = Math.max(1, size - overlap);
            for (int start = 0; start < words.length; start += step) {
                int end = Math.min(words.length, start + size);
                units.add(String.join(" ", java.util.Arrays.copyOfRange(words, start, end)));
                if (end == words.length) {
                    break;
                }
            }
        }
        return units;
    }

    private void emit(List<TextChunk> out, ExtractedSection section, String text) {
        String trimmed = text.trim();
        if (!trimmed.isEmpty()) {
            out.add(new TextChunk(out.size(), section.getPageNumber(), section.getTitle(), trimmed));
        }
    }

    private static String tail(String text, int tokens) {
        if (tokens <= 0) {
            return "";
        }
        String[] words = text.trim().split("\\s+");
        int from = Math.max(0, words.length - tokens);
        return String.join(" ", java.util.Arrays.copyOfRange(words, from, words.length));
    }

    private static int countTokens(String text) {
        String t = text.trim();
        return t.isEmpty() ? 0 : t.split("\\s+").length;
    }
}
