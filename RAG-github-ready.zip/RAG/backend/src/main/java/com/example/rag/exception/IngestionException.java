package com.example.rag.exception;

/** Raised when a document cannot be extracted, chunked, embedded or stored. Never exposed directly over HTTP. */
public class IngestionException extends RuntimeException {

    public IngestionException(String message) {
        super(message);
    }

    public IngestionException(String message, Throwable cause) {
        super(message, cause);
    }
}
