package com.example.rag.dto;

import java.time.LocalDateTime;
import java.util.List;

public class ChatMessageDto {

    public Long id;
    public String role;
    public String content;
    public List<SourceDto> sources;
    public LocalDateTime createdAt;
}
