export type ProcessingStatus = 'UPLOADED' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'REINDEXING';

export interface DocumentDto {
  id: number;
  originalFilename: string;
  fileType: string;
  fileSize: number;
  fileHash: string;
  totalChunks: number;
  processingStatus: ProcessingStatus;
  createdAt: string;
  updatedAt: string;
  lastIndexedAt: string | null;
  processingError: string | null;
  embeddingModel: string | null;
}

export interface ChunkDto {
  id: number;
  chunkIndex: number;
  text: string;
  pageNumber: number | null;
  sectionTitle: string | null;
}

export interface UploadResultDto {
  outcome: 'ACCEPTED' | 'REPLACED' | 'DUPLICATE' | 'REJECTED';
  filename: string;
  message: string;
  document: DocumentDto | null;
}

export interface ReindexAllResultDto {
  total: number;
  queued: number;
  failed: number;
  failures: { documentId: number; filename: string; reason: string }[];
}

export interface SourceDto {
  chunkId: number;
  documentId: number;
  documentName: string;
  pageNumber: number | null;
  sectionTitle: string | null;
  chunkIndex: number;
  similarity: number;
  text: string;
}

export interface ChatMessageDto {
  id: number;
  role: 'user' | 'assistant';
  content: string;
  sources: SourceDto[];
  createdAt: string;
}

export interface ChatResponseDto {
  conversationId: string;
  message: ChatMessageDto;
  sources: SourceDto[];
}

export interface ConversationDto {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessageDto[] | null;
  messageCount: number;
}

export interface ComponentStatus {
  up: boolean;
  message: string;
}

export interface OllamaModel {
  name: string;
  sizeBytes: number;
}

export interface OllamaStatus {
  reachable: boolean;
  url: string;
  message: string;
  chatModel: string;
  embeddingModel: string;
  chatModelAvailable: boolean;
  embeddingModelAvailable: boolean;
  models: OllamaModel[];
}

export interface DashboardStats {
  totalDocuments: number;
  completedDocuments: number;
  processingDocuments: number;
  failedDocuments: number;
  totalChunks: number;
}

export interface Health {
  status: 'UP' | 'DEGRADED';
  database: ComponentStatus;
  pgvector: ComponentStatus;
  ollama: OllamaStatus;
  stats: DashboardStats;
}

export interface SyncIssue {
  type: string;
  documentId: number | null;
  filename: string;
  detail: string;
}

export interface SyncReport {
  checkedAt: string;
  documentsChecked: number;
  issues: SyncIssue[];
  consistent: boolean;
}

export interface SyncRepair {
  issuesFound: number;
  repaired: number;
  failed: number;
  actions: string[];
}

export interface Settings {
  ollamaUrl: string;
  chatModel: string;
  embeddingModel: string;
  chunkSize: number;
  chunkOverlap: number;
  topK: number;
  similarityThreshold: number;
  storageLocation: string;
  maxUploadSizeMb: number;
  embeddingDimensions: number;
}
