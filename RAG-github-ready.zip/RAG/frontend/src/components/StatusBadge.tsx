import { AlertCircle, CheckCircle2, Clock, Loader2 } from 'lucide-react';
import type { ProcessingStatus } from '../types';

const STYLES: Record<ProcessingStatus, string> = {
  UPLOADED: 'bg-slate-100 text-slate-700',
  PROCESSING: 'bg-amber-100 text-amber-800',
  REINDEXING: 'bg-sky-100 text-sky-800',
  COMPLETED: 'bg-emerald-100 text-emerald-800',
  FAILED: 'bg-red-100 text-red-800',
};

export default function StatusBadge({ status }: { status: ProcessingStatus }) {
  let icon = <Clock size={12} />;
  if (status === 'PROCESSING' || status === 'REINDEXING') icon = <Loader2 size={12} className="animate-spin" />;
  if (status === 'COMPLETED') icon = <CheckCircle2 size={12} />;
  if (status === 'FAILED') icon = <AlertCircle size={12} />;
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${STYLES[status]}`}>
      {icon}
      {status}
    </span>
  );
}
