import type {
  ChatResponseDto,
  ChunkDto,
  ConversationDto,
  DocumentDto,
  Health,
  ReindexAllResultDto,
  Settings,
  SyncRepair,
  SyncReport,
  UploadResultDto,
} from './types';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, init);
  } catch {
    throw new ApiError('Cannot reach the backend server. Is it running on port 8080?', 0);
  }
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body && typeof body.message === 'string') message = body.message;
    } catch {
      /* ignore non-JSON error bodies */
    }
    throw new ApiError(message, response.status);
  }
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

function json(method: string, body?: unknown): RequestInit {
  return {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  };
}

/** Uploads with progress reporting (fetch cannot report upload progress). */
function upload<T>(url: string, method: string, form: FormData, onProgress?: (pct: number) => void): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(method, url);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onerror = () => reject(new ApiError('Cannot reach the backend server. Is it running on port 8080?', 0));
    xhr.onload = () => {
      let body: any = null;
      try {
        body = JSON.parse(xhr.responseText);
      } catch {
        /* ignore */
      }
      if (xhr.status >= 200 && xhr.status < 300) resolve(body as T);
      else reject(new ApiError(body?.message ?? `Upload failed (${xhr.status})`, xhr.status));
    };
    xhr.send(form);
  });
}

export const api = {
  health: () => request<Health>('/api/system/health'),
  ollamaModels: () => request<Health['ollama']['models']>('/api/system/ollama/models'),
  pullOllamaModel: (model: string) =>
    request<{ model: string; status: string }>('/api/system/ollama/pull', json('POST', { model })),
  validateSync: () => request<SyncReport>('/api/system/sync/validate', json('POST')),
  repairSync: () => request<SyncRepair>('/api/system/sync/repair', json('POST')),

  listDocuments: () => request<DocumentDto[]>('/api/documents'),
  documentChunks: (id: number) => request<ChunkDto[]>(`/api/documents/${id}/chunks`),
  deleteDocument: (id: number) => request<void>(`/api/documents/${id}`, { method: 'DELETE' }),
  reindexDocument: (id: number) => request<DocumentDto>(`/api/documents/${id}/reindex`, json('POST')),
  reindexAll: () => request<ReindexAllResultDto>('/api/documents/reindex-all', json('POST')),
  uploadDocuments: (files: File[], onProgress?: (pct: number) => void) => {
    const form = new FormData();
    files.forEach((f) => form.append('files', f));
    return upload<UploadResultDto[]>('/api/documents/upload/multiple', 'POST', form, onProgress);
  },
  replaceDocument: (id: number, file: File, onProgress?: (pct: number) => void) => {
    const form = new FormData();
    form.append('file', file);
    return upload<UploadResultDto>(`/api/documents/${id}`, 'PUT', form, onProgress);
  },

  ask: (question: string, conversationId: string | null) =>
    request<ChatResponseDto>('/api/chat/ask', json('POST', { question, conversationId })),
  chatHistory: () => request<ConversationDto[]>('/api/chat/history'),
  conversation: (id: string) => request<ConversationDto>(`/api/chat/${id}`),
  deleteConversation: (id: string) => request<void>(`/api/chat/${id}`, { method: 'DELETE' }),

  getSettings: () => request<Settings>('/api/settings'),
  saveSettings: (s: Settings) => request<Settings>('/api/settings', json('PUT', s)),
};
