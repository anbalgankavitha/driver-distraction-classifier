import { useCallback, useEffect, useRef, useState } from 'react';
import { Bot, ChevronDown, ChevronRight, FileText, Loader2, MessageSquarePlus, Send, Trash2, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { api } from '../api';
import type { ChatMessageDto, ConversationDto, SourceDto } from '../types';
import ErrorBanner from '../components/ErrorBanner';

interface UiMessage {
  key: string;
  role: 'user' | 'assistant';
  content: string;
  sources: SourceDto[];
}

function SourceList({ sources }: { sources: SourceDto[] }) {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  if (sources.length === 0) return null;

  return (
    <div className="mt-3 border-t border-slate-100 pt-2">
      <button className="flex items-center gap-1 text-xs font-medium text-slate-600" onClick={() => setOpen(!open)}>
        {open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        Sources ({sources.length})
      </button>
      <div className="mt-1 flex flex-wrap gap-1.5">
        {Array.from(new Set(sources.map((s) => `${s.documentName}${s.pageNumber != null ? ` · p.${s.pageNumber}` : ''}`))).map(
          (label) => (
            <span key={label} className="inline-flex items-center gap-1 rounded-full bg-indigo-50 px-2 py-0.5 text-xs text-indigo-700">
              <FileText size={11} />
              {label}
            </span>
          ),
        )}
      </div>
      {open && (
        <div className="mt-2 space-y-2">
          {sources.map((s, i) => (
            <div key={s.chunkId} className="rounded-lg border border-slate-200 bg-slate-50 text-xs">
              <button
                className="flex w-full items-center gap-2 px-3 py-2 text-left"
                onClick={() => setExpanded({ ...expanded, [i]: !expanded[i] })}
              >
                {expanded[i] ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                <span className="flex-1 truncate font-medium text-slate-700">
                  {s.documentName}
                  {s.pageNumber != null && ` — page ${s.pageNumber}`}
                  {s.sectionTitle && ` — ${s.sectionTitle}`}
                </span>
                <span className="text-slate-500">{(s.similarity * 100).toFixed(0)}% match</span>
              </button>
              {expanded[i] && <p className="whitespace-pre-wrap border-t border-slate-200 px-3 py-2 text-slate-600">{s.text}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function toUi(m: ChatMessageDto): UiMessage {
  return { key: `m${m.id}`, role: m.role, content: m.content, sources: m.sources ?? [] };
}

export default function Chat() {
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [history, setHistory] = useState<ConversationDto[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  const loadHistory = useCallback(async () => {
    try {
      setHistory(await api.chatHistory());
    } catch {
      /* history is non-critical */
    }
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  const send = async () => {
    const question = input.trim();
    if (!question || sending) return;
    setInput('');
    setError(null);
    setSending(true);
    setMessages((prev) => [...prev, { key: `u${Date.now()}`, role: 'user', content: question, sources: [] }]);
    try {
      const res = await api.ask(question, conversationId);
      setConversationId(res.conversationId);
      setMessages((prev) => [...prev, { key: `a${res.message.id}`, role: 'assistant', content: res.message.content, sources: res.sources }]);
      loadHistory();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSending(false);
    }
  };

  const open = async (id: string) => {
    try {
      const c = await api.conversation(id);
      setConversationId(c.id);
      setMessages((c.messages ?? []).map(toUi));
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const newChat = () => {
    setConversationId(null);
    setMessages([]);
    setError(null);
  };

  const clear = async () => {
    if (conversationId) {
      try {
        await api.deleteConversation(conversationId);
      } catch (e) {
        setError((e as Error).message);
        return;
      }
    }
    newChat();
    loadHistory();
  };

  const removeFromHistory = async (id: string) => {
    try {
      await api.deleteConversation(id);
      if (id === conversationId) newChat();
      loadHistory();
    } catch (e) {
      setError((e as Error).message);
    }
  };

  return (
    <div className="flex h-full min-h-0">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white lg:flex">
        <div className="p-3">
          <button className="btn btn-secondary w-full" onClick={newChat}>
            <MessageSquarePlus size={16} /> New chat
          </button>
        </div>
        <ul className="min-h-0 flex-1 space-y-0.5 overflow-y-auto px-2 pb-3">
          {history.map((c) => (
            <li key={c.id} className="group flex items-center">
              <button
                onClick={() => open(c.id)}
                className={`min-w-0 flex-1 truncate rounded-lg px-3 py-2 text-left text-sm ${
                  c.id === conversationId ? 'bg-indigo-50 text-indigo-700' : 'text-slate-700 hover:bg-slate-100'
                }`}
                title={c.title}
              >
                {c.title}
              </button>
              <button
                className="ml-1 hidden p-1 text-slate-400 hover:text-red-600 group-hover:block"
                onClick={() => removeFromHistory(c.id)}
                aria-label="Delete conversation"
              >
                <Trash2 size={14} />
              </button>
            </li>
          ))}
          {history.length === 0 && <li className="px-3 py-2 text-xs text-slate-400">No conversations yet</li>}
        </ul>
      </aside>

      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3">
          <h2 className="font-semibold text-slate-900">Ask your documents</h2>
          <div className="flex gap-2">
            <button className="btn btn-secondary lg:hidden" onClick={newChat}>
              <MessageSquarePlus size={16} /> New
            </button>
            <button className="btn btn-secondary" onClick={clear} disabled={messages.length === 0 || sending}>
              <Trash2 size={16} /> Clear conversation
            </button>
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-6">
          <div className="mx-auto max-w-3xl space-y-5">
            {messages.length === 0 && (
              <div className="py-16 text-center text-slate-500">
                <Bot className="mx-auto mb-3 text-slate-300" size={40} />
                <p className="font-medium text-slate-700">Ask a question about your indexed documents</p>
                <p className="text-sm">Answers use only your documents and always cite their sources. Follow-up questions are supported.</p>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.key} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                    m.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {m.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                </div>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm ${
                    m.role === 'user' ? 'bg-indigo-600 text-white' : 'border border-slate-200 bg-white text-slate-800'
                  }`}
                >
                  {m.role === 'assistant' ? (
                    <div className="markdown-content">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap">{m.content}</p>
                  )}
                  {m.role === 'assistant' && <SourceList sources={m.sources} />}
                </div>
              </div>
            ))}
            {sending && (
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <Loader2 size={16} className="animate-spin" /> Searching documents and generating an answer…
              </div>
            )}
            <div ref={bottom} />
          </div>
        </div>

        <footer className="border-t border-slate-200 bg-white px-4 py-3">
          <div className="mx-auto max-w-3xl space-y-2">
            <ErrorBanner message={error} onDismiss={() => setError(null)} />
            <div className="flex items-end gap-2">
              <textarea
                className="input max-h-40 min-h-[44px] resize-none"
                rows={1}
                placeholder="Ask a question…"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    send();
                  }
                }}
              />
              <button className="btn btn-primary h-11" onClick={send} disabled={sending || !input.trim()} aria-label="Send">
                <Send size={18} />
              </button>
            </div>
          </div>
        </footer>
      </section>
    </div>
  );
}
