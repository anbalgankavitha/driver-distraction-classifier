import { useCallback, useEffect, useState } from 'react';
import { Boxes, CheckCircle2, Cpu, Database, FileText, Loader2, RefreshCw, ShieldCheck, Wrench, XCircle } from 'lucide-react';
import { api } from '../api';
import type { Health, SyncRepair, SyncReport } from '../types';
import ErrorBanner from '../components/ErrorBanner';
import { formatBytes } from '../utils';

function Stat({ label, value, icon }: { label: string; value: number; icon: JSX.Element }) {
  return (
    <div className="card flex items-center gap-4 p-4">
      <div className="rounded-lg bg-indigo-50 p-2.5 text-indigo-600">{icon}</div>
      <div>
        <div className="text-2xl font-semibold text-slate-900">{value}</div>
        <div className="text-xs text-slate-500">{label}</div>
      </div>
    </div>
  );
}

function Status({ label, up, message, icon }: { label: string; up: boolean; message: string; icon: JSX.Element }) {
  return (
    <div className="card flex items-center gap-3 p-4">
      <div className={`rounded-lg p-2.5 ${up ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium text-slate-900">{label}</div>
        <div className="truncate text-xs text-slate-500">{message}</div>
      </div>
      {up ? <CheckCircle2 size={18} className="text-emerald-600" /> : <XCircle size={18} className="text-red-600" />}
    </div>
  );
}

export default function Dashboard() {
  const [health, setHealth] = useState<Health | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<SyncReport | null>(null);
  const [repair, setRepair] = useState<SyncRepair | null>(null);
  const [syncBusy, setSyncBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setHealth(await api.health());
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load]);

  const runSync = async (action: 'validate' | 'repair') => {
    setSyncBusy(true);
    try {
      if (action === 'validate') {
        setRepair(null);
        setReport(await api.validateSync());
      } else {
        setRepair(await api.repairSync());
        setReport(null);
      }
      setError(null);
      load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSyncBusy(false);
    }
  };

  const stats = health?.stats;

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-900">Dashboard</h2>
        <button className="btn btn-secondary" onClick={load}>
          <RefreshCw size={16} /> Refresh
        </button>
      </div>
      <ErrorBanner message={error} />

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Stat label="Total documents" value={stats?.totalDocuments ?? 0} icon={<FileText size={20} />} />
        <Stat label="Indexed" value={stats?.completedDocuments ?? 0} icon={<CheckCircle2 size={20} />} />
        <Stat label="Processing" value={stats?.processingDocuments ?? 0} icon={<Loader2 size={20} />} />
        <Stat label="Failed" value={stats?.failedDocuments ?? 0} icon={<XCircle size={20} />} />
        <Stat label="Indexed chunks" value={stats?.totalChunks ?? 0} icon={<Boxes size={20} />} />
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Status
          label="PostgreSQL"
          up={!!health?.database.up}
          message={health?.database.message ?? 'Checking…'}
          icon={<Database size={20} />}
        />
        <Status
          label="pgvector"
          up={!!health?.pgvector.up}
          message={health?.pgvector.message ?? 'Checking…'}
          icon={<Boxes size={20} />}
        />
        <Status
          label="Ollama"
          up={!!health?.ollama.reachable}
          message={health?.ollama.message ?? 'Checking…'}
          icon={<Cpu size={20} />}
        />
      </section>

      <section className="card p-5">
        <h3 className="mb-3 font-semibold text-slate-900">Ollama models</h3>
        {health?.ollama.reachable ? (
          <>
            <div className="mb-3 flex flex-wrap gap-2 text-xs">
              <span
                className={`rounded-full px-2 py-1 ${health.ollama.chatModelAvailable ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}
              >
                Chat: {health.ollama.chatModel} {health.ollama.chatModelAvailable ? '✓' : '(not pulled)'}
              </span>
              <span
                className={`rounded-full px-2 py-1 ${health.ollama.embeddingModelAvailable ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}
              >
                Embedding: {health.ollama.embeddingModel} {health.ollama.embeddingModelAvailable ? '✓' : '(not pulled)'}
              </span>
            </div>
            <ul className="divide-y divide-slate-100 text-sm">
              {health.ollama.models.map((m) => (
                <li key={m.name} className="flex justify-between py-1.5">
                  <span className="font-mono text-slate-700">{m.name}</span>
                  <span className="text-slate-500">{formatBytes(m.sizeBytes)}</span>
                </li>
              ))}
              {health.ollama.models.length === 0 && <li className="py-2 text-slate-500">No models installed.</li>}
            </ul>
          </>
        ) : (
          <p className="text-sm text-slate-500">Ollama is not reachable. Start Ollama to see available models.</p>
        )}
      </section>

      <section className="card p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-semibold text-slate-900">Index synchronization</h3>
            <p className="text-xs text-slate-500">
              Checks files, chunks, embeddings, hashes, duplicates and embedding models for consistency.
            </p>
          </div>
          <div className="flex gap-2">
            <button className="btn btn-secondary" disabled={syncBusy} onClick={() => runSync('validate')}>
              <ShieldCheck size={16} /> Validate
            </button>
            <button className="btn btn-primary" disabled={syncBusy} onClick={() => runSync('repair')}>
              <Wrench size={16} /> Repair
            </button>
          </div>
        </div>
        {syncBusy && <p className="text-sm text-slate-500">Working…</p>}
        {report && (
          <div className="text-sm">
            <p className={report.consistent ? 'text-emerald-700' : 'text-amber-700'}>
              {report.consistent
                ? `All ${report.documentsChecked} documents are consistent.`
                : `${report.issues.length} issue(s) found across ${report.documentsChecked} documents.`}
            </p>
            <ul className="mt-2 divide-y divide-slate-100">
              {report.issues.map((i, idx) => (
                <li key={idx} className="py-2">
                  <span className="mr-2 rounded bg-amber-100 px-1.5 py-0.5 text-xs font-medium text-amber-800">{i.type}</span>
                  <span className="font-medium">{i.filename}</span>
                  <div className="text-xs text-slate-500">{i.detail}</div>
                </li>
              ))}
            </ul>
          </div>
        )}
        {repair && (
          <div className="text-sm">
            <p className="text-slate-700">
              {repair.issuesFound} issue(s) found · {repair.repaired} repaired · {repair.failed} failed
            </p>
            <ul className="mt-2 list-disc pl-5 text-xs text-slate-600">
              {repair.actions.map((a, idx) => (
                <li key={idx}>{a}</li>
              ))}
            </ul>
          </div>
        )}
      </section>
    </div>
  );
}
