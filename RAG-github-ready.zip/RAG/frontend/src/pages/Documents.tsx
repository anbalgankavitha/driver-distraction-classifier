import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Eye, Loader2, RefreshCw, RefreshCcw, Search, Trash2, Upload } from 'lucide-react';
import { api } from '../api';
import type { ChunkDto, DocumentDto, ProcessingStatus, ReindexAllResultDto, UploadResultDto } from '../types';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';
import ErrorBanner from '../components/ErrorBanner';
import { formatBytes, formatDate, isBusy } from '../utils';

const ACCEPT = '.txt,.pdf,.doc,.docx';
const STATUSES: ProcessingStatus[] = ['UPLOADED', 'PROCESSING', 'COMPLETED', 'FAILED', 'REINDEXING'];

export default function Documents() {
  const [docs, setDocs] = useState<DocumentDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [uploadResults, setUploadResults] = useState<UploadResultDto[]>([]);
  const [reindexResult, setReindexResult] = useState<ReindexAllResultDto | null>(null);
  const [reindexingAll, setReindexingAll] = useState(false);
  const [toDelete, setToDelete] = useState<DocumentDto | null>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [confirmBulkDelete, setConfirmBulkDelete] = useState(false);
  const [confirmReindexAll, setConfirmReindexAll] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [viewing, setViewing] = useState<DocumentDto | null>(null);
  const [chunks, setChunks] = useState<ChunkDto[] | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const replaceInput = useRef<HTMLInputElement>(null);
  const replaceTarget = useRef<DocumentDto | null>(null);

  const load = useCallback(async () => {
    try {
      setDocs(await api.listDocuments());
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  const anyBusy = docs.some((d) => isBusy(d.processingStatus));

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const t = setInterval(load, anyBusy ? 2000 : 10000);
    return () => clearInterval(t);
  }, [load, anyBusy]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return docs.filter(
      (d) =>
        (!q || d.originalFilename.toLowerCase().includes(q)) &&
        (!typeFilter || d.fileType.toLowerCase() === typeFilter) &&
        (!statusFilter || d.processingStatus === statusFilter),
    );
  }, [docs, search, typeFilter, statusFilter]);

  // drop selections for documents that no longer exist
  useEffect(() => {
    setSelected((prev) => {
      const ids = new Set(docs.map((d) => d.id));
      const next = new Set(Array.from(prev).filter((id) => ids.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [docs]);

  const allFilteredSelected = filtered.length > 0 && filtered.every((d) => selected.has(d.id));

  const toggleOne = (id: number) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const toggleAll = () =>
    setSelected(allFilteredSelected ? new Set() : new Set(filtered.map((d) => d.id)));

  const deleteSelected = async () => {
    setBulkBusy(true);
    const ids = Array.from(selected);
    const results = await Promise.allSettled(ids.map((id) => api.deleteDocument(id)));
    const failed = results.filter((r) => r.status === 'rejected').length;
    setError(failed > 0 ? `${failed} of ${ids.length} document(s) could not be deleted.` : null);
    setSelected(new Set());
    setConfirmBulkDelete(false);
    setBulkBusy(false);
    load();
  };

  const reindexSelected = async () => {
    setBulkBusy(true);
    const ids = Array.from(selected);
    const results = await Promise.allSettled(ids.map((id) => api.reindexDocument(id)));
    const failed = results.filter((r) => r.status === 'rejected').length;
    setError(failed > 0 ? `${failed} of ${ids.length} document(s) could not be queued for reindexing.` : null);
    setSelected(new Set());
    setBulkBusy(false);
    load();
  };

  const processingCount = docs.filter((d) => isBusy(d.processingStatus)).length;

  const uploadFiles = async (files: File[]) => {
    if (files.length === 0) return;
    setProgress(0);
    setUploadResults([]);
    try {
      setUploadResults(await api.uploadDocuments(files, setProgress));
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setProgress(null);
      load();
    }
  };

  const onReplaceChosen = async (file: File | undefined) => {
    const target = replaceTarget.current;
    if (!file || !target) return;
    setProgress(0);
    try {
      setUploadResults([await api.replaceDocument(target.id, file, setProgress)]);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setProgress(null);
      replaceTarget.current = null;
      load();
    }
  };

  const reindex = async (d: DocumentDto) => {
    try {
      await api.reindexDocument(d.id);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    }
    load();
  };

  const reindexAll = async () => {
    setReindexingAll(true);
    try {
      setReindexResult(await api.reindexAll());
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setReindexingAll(false);
      load();
    }
  };

  const confirmDelete = async () => {
    if (!toDelete) return;
    try {
      await api.deleteDocument(toDelete.id);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    }
    setToDelete(null);
    load();
  };

  const view = async (d: DocumentDto) => {
    setViewing(d);
    setChunks(null);
    try {
      setChunks(await api.documentChunks(d.id));
    } catch (e) {
      setError((e as Error).message);
      setViewing(null);
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-5 p-4 md:p-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-semibold text-slate-900">Documents</h2>
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={() => setConfirmReindexAll(true)} disabled={reindexingAll || docs.length === 0}>
            {reindexingAll ? <Loader2 size={16} className="animate-spin" /> : <RefreshCcw size={16} />} Reindex all
          </button>
          <button className="btn btn-primary" onClick={() => fileInput.current?.click()}>
            <Upload size={16} /> Upload
          </button>
        </div>
      </div>

      <input
        ref={fileInput}
        type="file"
        multiple
        accept={ACCEPT}
        className="hidden"
        onChange={(e) => {
          uploadFiles(Array.from(e.target.files ?? []));
          e.target.value = '';
        }}
      />
      <input
        ref={replaceInput}
        type="file"
        accept={ACCEPT}
        className="hidden"
        onChange={(e) => {
          onReplaceChosen(e.target.files?.[0]);
          e.target.value = '';
        }}
      />

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          uploadFiles(Array.from(e.dataTransfer.files));
        }}
        className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed px-4 py-8 text-center transition ${
          dragging ? 'border-indigo-500 bg-indigo-50' : 'border-slate-300 bg-white'
        }`}
      >
        <Upload className="mb-2 text-slate-400" />
        <p className="text-sm text-slate-700">Drag and drop TXT, PDF, DOC or DOCX files here</p>
        <p className="text-xs text-slate-500">
          Uploading a file with an existing name replaces that document; identical content is skipped.
        </p>
        {progress !== null && (
          <div className="mt-3 w-full max-w-xs">
            <div className="h-2 overflow-hidden rounded-full bg-slate-200">
              <div className="h-full bg-indigo-600 transition-all" style={{ width: `${progress}%` }} />
            </div>
            <p className="mt-1 text-xs text-slate-500">Uploading… {progress}%</p>
          </div>
        )}
      </div>

      <ErrorBanner message={error} onDismiss={() => setError(null)} />

      {uploadResults.length > 0 && (
        <div className="card space-y-1 p-3 text-sm">
          {uploadResults.map((r, i) => (
            <div key={i} className="flex items-start gap-2">
              <span
                className={`mt-0.5 rounded px-1.5 py-0.5 text-xs font-medium ${
                  r.outcome === 'REJECTED' ? 'bg-red-100 text-red-800' : r.outcome === 'DUPLICATE' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {r.outcome}
              </span>
              <span>
                <b>{r.filename}</b> — {r.message}
              </span>
            </div>
          ))}
        </div>
      )}

      {reindexResult && (
        <div className="card p-3 text-sm">
          Reindex all: {reindexResult.queued} of {reindexResult.total} queued, {reindexResult.failed} could not be queued.
          <ul className="mt-1 list-disc pl-5 text-xs text-red-700">
            {reindexResult.failures.map((f) => (
              <li key={f.documentId}>
                {f.filename}: {f.reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      {processingCount > 0 && (
        <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">
          <Loader2 size={16} className="animate-spin" />
          {processingCount} of {docs.length} document(s) are being processed…
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
          <input className="input pl-9" placeholder="Search documents…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="input w-auto" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
          <option value="">All types</option>
          {['txt', 'pdf', 'doc', 'docx'].map((t) => (
            <option key={t} value={t}>
              {t.toUpperCase()}
            </option>
          ))}
        </select>
        <select className="input w-auto" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {selected.size > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-sm">
          <span className="font-medium text-indigo-800">{selected.size} selected</span>
          <div className="flex gap-2">
            <button className="btn btn-secondary" onClick={() => setSelected(new Set())} disabled={bulkBusy}>
              Clear selection
            </button>
            <button className="btn btn-secondary" onClick={reindexSelected} disabled={bulkBusy}>
              <RefreshCw size={16} /> Reindex selected
            </button>
            <button className="btn btn-danger" onClick={() => setConfirmBulkDelete(true)} disabled={bulkBusy}>
              <Trash2 size={16} /> Delete selected
            </button>
          </div>
        </div>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full min-w-[860px] text-left text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="w-10 px-4 py-3">
                <input type="checkbox" checked={allFilteredSelected} onChange={toggleAll} aria-label="Select all" />
              </th>
              <th className="px-4 py-3">Document name</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Size</th>
              <th className="px-4 py-3">Uploaded</th>
              <th className="px-4 py-3">Chunks</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading && (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                  {docs.length === 0 ? 'No documents yet. Upload your first document above.' : 'No documents match the filters.'}
                </td>
              </tr>
            )}
            {filtered.map((d) => (
              <tr key={d.id} className={selected.has(d.id) ? 'bg-indigo-50/50' : 'hover:bg-slate-50'}>
                <td className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selected.has(d.id)}
                    onChange={() => toggleOne(d.id)}
                    aria-label={`Select ${d.originalFilename}`}
                  />
                </td>
                <td className="max-w-[280px] px-4 py-3">
                  <div className="truncate font-medium text-slate-900" title={d.originalFilename}>
                    {d.originalFilename}
                  </div>
                  {d.processingError && (
                    <div className="truncate text-xs text-red-600" title={d.processingError}>
                      {d.processingError}
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 uppercase">{d.fileType}</td>
                <td className="px-4 py-3">{formatBytes(d.fileSize)}</td>
                <td className="px-4 py-3">{formatDate(d.createdAt)}</td>
                <td className="px-4 py-3">{d.totalChunks}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={d.processingStatus} />
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <button className="btn btn-secondary px-2" title="View chunks" onClick={() => view(d)}>
                      <Eye size={15} />
                    </button>
                    <button
                      className="btn btn-secondary px-2"
                      title="Reindex"
                      disabled={isBusy(d.processingStatus)}
                      onClick={() => reindex(d)}
                    >
                      <RefreshCw size={15} />
                    </button>
                    <button
                      className="btn btn-secondary px-2"
                      title="Replace with a new file"
                      disabled={isBusy(d.processingStatus)}
                      onClick={() => {
                        replaceTarget.current = d;
                        replaceInput.current?.click();
                      }}
                    >
                      <Upload size={15} />
                    </button>
                    <button className="btn btn-secondary px-2 text-red-600" title="Delete" onClick={() => setToDelete(d)}>
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {toDelete && (
        <Modal title="Delete document" onClose={() => setToDelete(null)}>
          <p className="text-sm text-slate-700">
            Delete <b>{toDelete.originalFilename}</b>? Its file, chunks and embeddings will be permanently removed and
            it will no longer be searchable.
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <button className="btn btn-secondary" onClick={() => setToDelete(null)}>
              Cancel
            </button>
            <button className="btn btn-danger" onClick={confirmDelete}>
              <Trash2 size={16} /> Delete
            </button>
          </div>
        </Modal>
      )}

      {confirmBulkDelete && (
        <Modal title="Delete selected documents" onClose={() => setConfirmBulkDelete(false)}>
          <p className="text-sm text-slate-700">
            Delete <b>{selected.size}</b> selected document(s)? Their files, chunks and embeddings will be permanently
            removed and they will no longer be searchable.
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <button className="btn btn-secondary" onClick={() => setConfirmBulkDelete(false)} disabled={bulkBusy}>
              Cancel
            </button>
            <button className="btn btn-danger" onClick={deleteSelected} disabled={bulkBusy}>
              {bulkBusy ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />} Delete
            </button>
          </div>
        </Modal>
      )}

      {confirmReindexAll && (
        <Modal title="Reindex all documents" onClose={() => setConfirmReindexAll(false)}>
          <p className="text-sm text-slate-700">
            Re-extract and re-embed all {docs.length} document(s)? Existing indexes stay searchable until each new
            index is ready, and a failed document keeps its previous index.
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <button className="btn btn-secondary" onClick={() => setConfirmReindexAll(false)}>
              Cancel
            </button>
            <button
              className="btn btn-primary"
              onClick={() => {
                setConfirmReindexAll(false);
                reindexAll();
              }}
            >
              <RefreshCcw size={16} /> Reindex all
            </button>
          </div>
        </Modal>
      )}

      {viewing && (
        <Modal title={`${viewing.originalFilename} — chunks`} wide onClose={() => setViewing(null)}>
          {chunks === null ? (
            <p className="text-sm text-slate-500">Loading…</p>
          ) : chunks.length === 0 ? (
            <p className="text-sm text-slate-500">This document has no indexed chunks.</p>
          ) : (
            <div className="space-y-3">
              {chunks.map((c) => (
                <div key={c.id} className="rounded-lg border border-slate-200 p-3">
                  <div className="mb-1 text-xs text-slate-500">
                    Chunk #{c.chunkIndex + 1}
                    {c.pageNumber != null && ` · page ${c.pageNumber}`}
                    {c.sectionTitle && ` · ${c.sectionTitle}`}
                  </div>
                  <p className="whitespace-pre-wrap text-sm text-slate-700">{c.text}</p>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}
