import { useEffect, useState } from 'react';
import { CheckCircle2, Download, Loader2, RefreshCw, Save } from 'lucide-react';
import { api } from '../api';
import type { OllamaModel, Settings } from '../types';
import ErrorBanner from '../components/ErrorBanner';

function Field({ label, hint, children }: { label: string; hint?: string; children: JSX.Element }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [modelToPull, setModelToPull] = useState('');
  const [pulling, setPulling] = useState(false);
  const [refreshingModels, setRefreshingModels] = useState(false);
  const [modelNotice, setModelNotice] = useState<string | null>(null);
  const [reindexing, setReindexing] = useState(false);
  const [reindexNotice, setReindexNotice] = useState<string | null>(null);

  useEffect(() => {
    api
      .getSettings()
      .then(setSettings)
      .catch((e) => setError((e as Error).message));
    api
      .ollamaModels()
      .then(setModels)
      .catch(() => undefined);
  }, []);

  if (!settings) {
    return (
      <div className="p-8">
        <ErrorBanner message={error} />
        {!error && <p className="text-sm text-slate-500">Loading…</p>}
      </div>
    );
  }

  const set = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings({ ...settings, [key]: value });
    setSaved(false);
  };
  const num = (v: string) => (v === '' ? 0 : Number(v));

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      setSettings(await api.saveSettings(settings));
      setSaved(true);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const refreshModels = async () => {
    setRefreshingModels(true);
    setError(null);
    try {
      setModels(await api.ollamaModels());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setRefreshingModels(false);
    }
  };

  const pullModel = async () => {
    const model = modelToPull.trim();
    if (!model || pulling) return;
    setPulling(true);
    setError(null);
    setModelNotice(`Pulling ${model}. Large models can take several minutes to download.`);
    try {
      const result = await api.pullOllamaModel(model);
      setModels(await api.ollamaModels());
      setModelNotice(`${result.model} is installed. Choose it from the model selectors above.`);
      setModelToPull('');
    } catch (e) {
      setModelNotice(null);
      setError((e as Error).message);
    } finally {
      setPulling(false);
    }
  };

  const reindexAll = async () => {
    setReindexing(true);
    setError(null);
    setReindexNotice(null);
    try {
      const result = await api.reindexAll();
      setReindexNotice(`Reindex queued for ${result.queued} of ${result.total} documents${result.failed ? `; ${result.failed} could not be queued` : ''}.`);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setReindexing(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5 p-4 md:p-8">
      <h2 className="text-xl font-semibold text-slate-900">Settings</h2>
      <ErrorBanner message={error} onDismiss={() => setError(null)} />

      <section className="card space-y-4 p-5">
        <div className="flex items-center justify-between gap-3">
          <h3 className="font-semibold text-slate-900">Ollama</h3>
          <button type="button" className="btn btn-secondary" onClick={refreshModels} disabled={refreshingModels || pulling}>
            {refreshingModels ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />} Refresh models
          </button>
        </div>
        <Field label="Ollama URL">
          <input className="input" value={settings.ollamaUrl} onChange={(e) => set('ollamaUrl', e.target.value)} />
        </Field>
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Chat model">
            <select className="input" value={settings.chatModel} onChange={(e) => set('chatModel', e.target.value)}>
              {settings.chatModel && !models.some((m) => m.name === settings.chatModel) && (
                <option value={settings.chatModel}>{settings.chatModel} (configured)</option>
              )}
              {models.map((m) => <option key={m.name} value={m.name}>{m.name}</option>)}
            </select>
          </Field>
          <Field
            label="Embedding model"
            hint={`Changing it makes existing embeddings outdated — use “Reindex all”. Vector dimension is fixed at ${settings.embeddingDimensions}.`}
          >
            <select className="input" value={settings.embeddingModel} onChange={(e) => set('embeddingModel', e.target.value)}>
              {settings.embeddingModel && !models.some((m) => m.name === settings.embeddingModel) && (
                <option value={settings.embeddingModel}>{settings.embeddingModel} (configured)</option>
              )}
              {models.map((m) => <option key={m.name} value={m.name}>{m.name}</option>)}
            </select>
          </Field>
        </div>
        <div className="border-t border-slate-100 pt-4">
          <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="pull-model-name">Pull a model</label>
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              id="pull-model-name"
              className="input min-w-0 flex-1"
              placeholder="Model name, e.g. qwen3:8b"
              value={modelToPull}
              onChange={(e) => setModelToPull(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') pullModel(); }}
              disabled={pulling}
            />
            <button type="button" className="btn btn-secondary" onClick={pullModel} disabled={pulling || !modelToPull.trim()}>
              {pulling ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} {pulling ? 'Pulling…' : 'Pull model'}
            </button>
          </div>
          <p className="mt-1 text-xs text-slate-500">Enter an Ollama model name. The model will download from the configured Ollama server.</p>
          {modelNotice && <p className="mt-2 text-sm text-indigo-700" role="status">{modelNotice}</p>}
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h3 className="font-semibold text-slate-900">Chunking & retrieval</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Chunk size (approx. tokens)" hint="Chunk size and overlap use whitespace-separated words as a token estimate. They apply to new uploads; after saving, go to Documents and choose Reindex all to apply them to existing documents.">
            <input className="input" type="number" min={50} value={settings.chunkSize} onChange={(e) => set('chunkSize', num(e.target.value))} />
          </Field>
          <Field label="Chunk overlap (tokens)">
            <input className="input" type="number" min={0} value={settings.chunkOverlap} onChange={(e) => set('chunkOverlap', num(e.target.value))} />
          </Field>
          <Field label="Top-K retrieval">
            <input className="input" type="number" min={1} max={50} value={settings.topK} onChange={(e) => set('topK', num(e.target.value))} />
          </Field>
          <Field label="Similarity threshold (0–1)">
            <input
              className="input"
              type="number"
              min={0}
              max={1}
              step={0.05}
              value={settings.similarityThreshold}
              onChange={(e) => set('similarityThreshold', num(e.target.value))}
            />
          </Field>
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h3 className="font-semibold text-slate-900">Storage</h3>
        <Field label="File storage location" hint="New uploads are stored here. Existing files stay where they are.">
          <input className="input" value={settings.storageLocation} onChange={(e) => set('storageLocation', e.target.value)} />
        </Field>
        <Field label="Maximum upload size (MB)">
          <input className="input" type="number" min={1} value={settings.maxUploadSizeMb} onChange={(e) => set('maxUploadSizeMb', num(e.target.value))} />
        </Field>
      </section>

      <div className="flex items-center gap-3">
        <button className="btn btn-primary" onClick={save} disabled={saving}>
          {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Save settings
        </button>
        {saved && (
          <span className="flex items-center gap-1 text-sm text-emerald-700">
            <CheckCircle2 size={16} /> Saved
          </span>
        )}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <button type="button" className="btn btn-secondary" onClick={reindexAll} disabled={reindexing || saving || !saved}>
          {reindexing ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
          {reindexing ? 'Queueing reindex…' : saved ? 'Reindex all documents with these chunk settings' : 'Save settings before reindexing'}
        </button>
        {reindexNotice && <span className="text-sm text-slate-600" role="status">{reindexNotice}</span>}
      </div>
    </div>
  );
}
