import { useState } from 'react';
import { FileText, LayoutDashboard, MessageSquare, Settings as SettingsIcon } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Documents from './pages/Documents';
import Chat from './pages/Chat';
import SettingsPage from './pages/SettingsPage';

type Page = 'dashboard' | 'documents' | 'chat' | 'settings';

const NAV: { id: Page; label: string; icon: typeof FileText }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'documents', label: 'Documents', icon: FileText },
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'settings', label: 'Settings', icon: SettingsIcon },
];

export default function App() {
  const [page, setPage] = useState<Page>('dashboard');

  return (
    <div className="flex h-full flex-col md:flex-row">
      <aside className="flex shrink-0 items-center gap-1 border-b border-slate-200 bg-white px-3 py-2 md:w-60 md:flex-col md:items-stretch md:border-b-0 md:border-r md:px-4 md:py-6">
        <div className="mr-3 hidden px-2 pb-4 md:block">
          <h1 className="text-lg font-semibold text-slate-900">DocIntel</h1>
          <p className="text-xs text-slate-500">Local RAG · Ollama · pgvector</p>
        </div>
        <nav className="flex flex-1 gap-1 overflow-x-auto md:flex-none md:flex-col">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setPage(id)}
              className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium transition ${
                page === id ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon size={18} />
              {label}
            </button>
          ))}
        </nav>
      </aside>

      <main className="min-h-0 flex-1 overflow-y-auto">
        {/* Pages stay mounted so chat state survives navigation */}
        <div className={page === 'dashboard' ? '' : 'hidden'}>{page === 'dashboard' && <Dashboard />}</div>
        <div className={page === 'documents' ? '' : 'hidden'}>{page === 'documents' && <Documents />}</div>
        <div className={page === 'chat' ? 'h-full' : 'hidden'}>
          <Chat />
        </div>
        <div className={page === 'settings' ? '' : 'hidden'}>{page === 'settings' && <SettingsPage />}</div>
      </main>
    </div>
  );
}
