import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        // chat answers from a local LLM can take minutes
        timeout: 600000,
        proxyTimeout: 600000,
      },
    },
  },
});
